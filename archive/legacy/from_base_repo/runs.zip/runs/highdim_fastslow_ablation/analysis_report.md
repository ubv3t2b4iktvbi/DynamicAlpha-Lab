# Result analysis

## Best model by task

### lorenz96_k32_partial_noisy
- best one_step_rmse: `ngrc_raw` = 0.0347741
- best rmse@10: `rc_fastslow_readout` = 0.0385224
- best rmse@50: `ngrc_fastslow_readout` = 1.71293
- best rmse@100: `ngrc_fastslow_readout` = 4.18927
- best acf_rmse: `ngrc_fastslow_readout` = 0.184883
- best psd_rmse: `ngrc_raw` = 0.0297289
- metadata: state_dim=32, family=`highdim_chaotic`, regime=`dimension_scaling_noisy`

### lorenz96_twoscale_k16_j4_noisy
- best one_step_rmse: `ngrc_fastslow_readout` = 0.0281151
- best rmse@10: `ngrc_raw` = 0.0466136
- best rmse@50: `ngrc_raw` = 0.292047
- best rmse@100: `ngrc_raw` = 1.13034
- best acf_rmse: `ngrc_raw` = 0.0130781
- best psd_rmse: `ngrc_raw` = 0.0102792
- metadata: state_dim=80, family=`highdim_multiscale`, regime=`dimension_scaling_noisy`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| ngrc_raw                |       0.0316277 | 0.100531  |   1.0777  |    2.74779 |   0.105181 |  0.0200041 |           231   |            231   |          231   |          1.53378 |            3670.08  |
| ngrc_fastslow_readout   |       0.0314467 | 0.121017  |   1.2187  |    2.9288  |   0.105265 |  0.027258  |           178.5 |            178.5 |          178.5 |          1.7468  |            3520.63  |
| hybrid_rc_ngrc_fastslow |       0.0323129 | 0.199385  |   2.95443 |    6.64949 |   0.420797 |  0.042587  |           188   |            188   |         9620   |         18.5396  |            2169.61  |
| rc_raw                  |       0.036672  | 0.264257  |   3.35846 |    7.74711 |   0.301642 |  0.0425196 |           120   |            122   |        14762   |          4.48137 |             216.018 |
| rc_fastslow_readout     |       0.0347786 | 0.0687527 |   3.94728 |   11.6493  |   0.388699 |  0.03554   |           180   |            184   |        36544   |          5.14005 |             357.467 |

## Family-wise averages

|                                                   |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |
|:--------------------------------------------------|----------:|----------:|-----------:|-----------:|-----------:|
| ('highdim_multiscale', 'ngrc_raw')                | 0.0466136 |  0.292047 |    1.13034 |  0.0130781 |  0.0102792 |
| ('highdim_multiscale', 'rc_fastslow_readout')     | 0.098983  |  0.524661 |    1.264   |  0.0249968 |  0.0110511 |
| ('highdim_multiscale', 'ngrc_fastslow_readout')   | 0.0670569 |  0.724479 |    1.66833 |  0.0256475 |  0.0241511 |
| ('highdim_chaotic', 'ngrc_fastslow_readout')      | 0.174978  |  1.71293  |    4.18927 |  0.184883  |  0.0303648 |
| ('highdim_chaotic', 'ngrc_raw')                   | 0.154448  |  1.86336  |    4.36524 |  0.197283  |  0.0297289 |
| ('highdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.150246  |  2.34561  |    3.23928 |  0.0402825 |  0.0232071 |
| ('highdim_multiscale', 'rc_raw')                  | 0.210108  |  2.99573  |    4.13257 |  0.0517322 |  0.0344058 |
| ('highdim_chaotic', 'hybrid_rc_ngrc_fastslow')    | 0.248524  |  3.56325  |   10.0597  |  0.801311  |  0.0619669 |
| ('highdim_chaotic', 'rc_raw')                     | 0.318406  |  3.72119  |   11.3616  |  0.551552  |  0.0506333 |
| ('highdim_chaotic', 'rc_fastslow_readout')        | 0.0385224 |  7.3699   |   22.0346  |  0.752401  |  0.0600289 |

## Dimension scaling

|   state_dim | variant                 |   rmse@50 |   rmse@100 |   one_step_rmse |
|------------:|:------------------------|----------:|-----------:|----------------:|
|          32 | ngrc_fastslow_readout   |  1.71293  |    4.18927 |       0.0347783 |
|          32 | ngrc_raw                |  1.86336  |    4.36524 |       0.0347741 |
|          32 | hybrid_rc_ngrc_fastslow |  3.56325  |   10.0597  |       0.0359373 |
|          32 | rc_raw                  |  3.72119  |   11.3616  |       0.0408798 |
|          32 | rc_fastslow_readout     |  7.3699   |   22.0346  |       0.040687  |
|          80 | ngrc_raw                |  0.292047 |    1.13034 |       0.0284812 |
|          80 | rc_fastslow_readout     |  0.524661 |    1.264   |       0.0288703 |
|          80 | ngrc_fastslow_readout   |  0.724479 |    1.66833 |       0.0281151 |
|          80 | hybrid_rc_ngrc_fastslow |  2.34561  |    3.23928 |       0.0286885 |
|          80 | rc_raw                  |  2.99573  |    4.13257 |       0.0324642 |

### Best variant per state dimension
|   state_dim | best_variant          |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:----------------------|-------------:|-------------:|--------------:|
|          32 | ngrc_fastslow_readout |            1 |     1.71293  |       4.18927 |
|          80 | ngrc_raw              |            1 |     0.292047 |       1.13034 |

## Ablation summary

| comparison                   | baseline            | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                                               |
|:-----------------------------|:--------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:-----------------------------------------------------------------------------------------|
| dual_memory_vs_single_memory | rc_fastslow_readout | hybrid_rc_ngrc_fastslow |       2 |          0.992853 |           4.9998   |                  9.19826 | Combining recurrent and delay memories should improve horizon balance.                   |
| fastslow_on_ngrc             | ngrc_raw            | ngrc_fastslow_readout   |       2 |         -0.141    |          -0.181013 |                 -5.59118 | Fast/slow readout should help NGRC resolve latent slow context.                          |
| fastslow_on_rc               | rc_raw              | rc_fastslow_readout     |       2 |         -0.588821 |          -3.90219  |                 -8.00189 | Fast/slow readout should help under scalar partial observation at matched RC state size. |

## One-step vs long-horizon mismatch

| task                           | variant                 |   one_step_rmse |   rmse@50 |   mismatch_ratio |   state_dim |
|:-------------------------------|:------------------------|----------------:|----------:|-----------------:|------------:|
| lorenz96_k32_partial_noisy     | rc_fastslow_readout     |       0.040687  |  7.3699   |         181.136  |          32 |
| lorenz96_k32_partial_noisy     | hybrid_rc_ngrc_fastslow |       0.0359373 |  3.56325  |          99.1518 |          32 |
| lorenz96_twoscale_k16_j4_noisy | rc_raw                  |       0.0324642 |  2.99573  |          92.278  |          80 |
| lorenz96_k32_partial_noisy     | rc_raw                  |       0.0408798 |  3.72119  |          91.0277 |          32 |
| lorenz96_twoscale_k16_j4_noisy | hybrid_rc_ngrc_fastslow |       0.0286885 |  2.34561  |          81.7612 |          80 |
| lorenz96_k32_partial_noisy     | ngrc_raw                |       0.0347741 |  1.86336  |          53.5846 |          32 |
| lorenz96_k32_partial_noisy     | ngrc_fastslow_readout   |       0.0347783 |  1.71293  |          49.2527 |          32 |
| lorenz96_twoscale_k16_j4_noisy | ngrc_fastslow_readout   |       0.0281151 |  0.724479 |          25.7683 |          80 |
| lorenz96_twoscale_k16_j4_noisy | rc_fastslow_readout     |       0.0288703 |  0.524661 |          18.1731 |          80 |
| lorenz96_twoscale_k16_j4_noisy | ngrc_raw                |       0.0284812 |  0.292047 |          10.254  |          80 |

## Insights

- Fast/slow features do not reliably fix NGRC long-rollout instability, so the issue is not only missing coarse variables but also accumulated autoregressive error.
- The RC+NGRC hybrid improves the one-step to long-horizon mismatch relative to single-memory RC, indicating that recurrent state and explicit delay coordinates contribute complementary memory.
- On the current high-dimensional tasks, `ngrc_fastslow_readout` wins most often, so claims should be framed around partial-observation structure rather than universal dominance.

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `ngrc_fastslow_readout` is only the most frequent winner, not a universal winner.
- Strength: the updated suite now includes higher-dimensional Lorenz-96 scaling tasks, which makes the evaluation less vulnerable to the criticism that the benchmark is only low-dimensional.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
