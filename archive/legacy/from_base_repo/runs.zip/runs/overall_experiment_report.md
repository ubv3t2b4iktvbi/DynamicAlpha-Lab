﻿# 总体实验报告

## 1. 实验范围

本轮实验一共覆盖了三类主实验和两类定向消融：

1. 低维主实验
   - `runs/lowdim_common_research`
   - `runs/lowdim_hard_research`
2. 高维主实验
   - `runs/highdim_research`
3. 定向消融
   - `runs/highdim_fastslow_ablation`
   - `runs/highdim_structured_ablation`

主实验总计 12 个任务：

- 低维任务 7 个
- 高维任务 5 个

所有主实验都采用同一组研究模型：

- `rc_fastslow_readout`
- `ngrc_fastslow_readout`
- `hybrid_rc_ngrc_fastslow`
- `slow_sindy_only`
- `slow_sindy_delta_rc`
- `slow_sindy_delta_ngrc`
- `slow_sindy_delta_hybrid`

## 2. 总体结论

### 2.1 任务胜场

按 `rmse@50` 统计，12 个主任务的获胜次数为：

- `rc_fastslow_readout`: `5 / 12`
- `hybrid_rc_ngrc_fastslow`: `3 / 12`
- `ngrc_fastslow_readout`: `3 / 12`
- `slow_sindy_delta_rc`: `1 / 12`

这说明当前结果最重要的事实不是“谁绝对最强”，而是“不同 regime 下最优模型发生切换”。

### 2.2 按任务族的最佳默认选择

按 `task_family` 聚合的平均 `rmse@50`：

| 任务族 | 最优模型 | 平均 `rmse@50` | 解释 |
|---|---:|---:|---|
| `lowdim_multiscale` | `rc_fastslow_readout` | `0.0124` | 低维多尺度下，带 fast/slow 读出的 RC 最稳健 |
| `lowdim_chaotic` | `hybrid_rc_ngrc_fastslow` | `0.9533` | 低维混沌下，双记忆模型比纯 RC / 纯 NGRC 更稳 |
| `forced_nonlinear` | `hybrid_rc_ngrc_fastslow` | `0.0311` | Duffing 这类受迫系统更偏向混合记忆结构 |
| `highdim_chaotic` | `hybrid_rc_ngrc_fastslow` | `2.1725` | 高维混沌标量观测下，hybrid 略优于 NGRC 和 slow-only |
| `highdim_multiscale` | `rc_fastslow_readout` | `0.3212` | 高维多尺度任务里，RC + fast/slow 读出仍然是最强默认项 |

从这个表可以看到：

- 低维多尺度问题适合 `rc_fastslow_readout`
- 低维混沌和部分高维混沌问题更适合 `hybrid_rc_ngrc_fastslow`
- 高维多尺度 noisy 问题里，结构化残差模型开始变得必要

## 3. 低维实验结论

### 3.1 低维总体表现

把低维主实验整体合并后，平均 `rmse@50` 排名为：

- `rc_fastslow_readout`: `0.7684`
- `hybrid_rc_ngrc_fastslow`: `0.8042`
- `slow_sindy_only`: `2.6515`
- `slow_sindy_delta_hybrid`: `2.9297`
- `slow_sindy_delta_ngrc`: `3.2578`
- `ngrc_fastslow_readout`: `3.8955`
- `slow_sindy_delta_rc`: `5.4522`

低维实验的主结论很明确：

1. `rc_fastslow_readout` 是最稳的低维默认模型。
2. 在低维 chaotic 子族上，`hybrid_rc_ngrc_fastslow` 更强。
3. `ngrc_fastslow_readout` 在若干低维任务里 one-step 很好，但 rollout 失稳明显。

### 3.2 低维代表性发现

- `lorenz63_clean`:
  - 最优 `rmse@50`: `rc_fastslow_readout = 0.2372`
- `lorenz63_noisy`:
  - 最优 `rmse@50`: `hybrid_rc_ngrc_fastslow = 0.0981`
- `rossler_clean`:
  - 最优 `rmse@50`: `ngrc_fastslow_readout = 0.00827`
  - 但 `rmse@100` 上 `rc_fastslow_readout` 更稳
- `vanderpol_stiff`:
  - `rc_fastslow_readout` 和 `hybrid_rc_ngrc_fastslow` 都几乎完美
- `fitzhugh_nagumo_noisy`:
  - 最优 `rmse@50`: `rc_fastslow_readout = 0.0162`
- `vanderpol_shorttrain`:
  - 最优 `rmse@50`: `rc_fastslow_readout = 0.0210`
  - 说明在小样本低维多尺度下，RC 的鲁棒性优于 NGRC

### 3.3 低维 insight

- 在低维任务上，显式 fast/slow 读出是很强的 inductive bias。
- 但 SINDy slow backbone 在低维混沌问题上并不占优，说明低维 chaotic 任务的主瓶颈不是慢变量显式建模，而是稳定的短中期闭环预测。
- `slow_sindy_only` 的 mismatch 最小，但精度并不最好，说明“动力学平滑”不等于“预测最优”。

## 4. 高维实验结论

### 4.1 高维总体表现

高维主实验平均 `rmse@50` 排名为：

- `ngrc_fastslow_readout`: `1.6726`
- `slow_sindy_only`: `1.6912`
- `hybrid_rc_ngrc_fastslow`: `1.8019`
- `slow_sindy_delta_rc`: `2.0382`
- `slow_sindy_delta_ngrc`: `2.6448`
- `slow_sindy_delta_hybrid`: `2.6634`
- `rc_fastslow_readout`: `3.1428`

但这个平均值不能直接理解为“NGRC 全面最强”，因为任务族内部差异非常大。

### 4.2 高维分族结果

高维混沌：

- `hybrid_rc_ngrc_fastslow`: `2.1725`
- `slow_sindy_only`: `2.2395`
- `ngrc_fastslow_readout`: `2.3826`

高维多尺度：

- `rc_fastslow_readout`: `0.3212`
- `ngrc_fastslow_readout`: `0.6076`
- `slow_sindy_delta_rc`: `0.8620`

这说明：

- 高维 chaotic 标量观测更依赖记忆结构
- 高维 multiscale 标量观测更依赖 fast/slow 读出与中等复杂度闭环
- 结构化 residual 模型只在最难的 noisy multiscale 任务上显示出明显优势

### 4.3 高维代表性任务

- `lorenz96_k16_partial`:
  - 最优 `rmse@50`: `hybrid_rc_ngrc_fastslow = 1.1379`
- `lorenz96_k32_partial`:
  - 最优 `rmse@50`: `ngrc_fastslow_readout = 0.8544`
- `lorenz96_k32_partial_noisy`:
  - 最优 `rmse@50`: `ngrc_fastslow_readout = 1.7129`
- `lorenz96_twoscale_k12_j6`:
  - 最优 `rmse@50`: `rc_fastslow_readout = 0.1176`
- `lorenz96_twoscale_k16_j4_noisy`:
  - 最优 `rmse@50`: `slow_sindy_delta_rc = 0.4136`

最值得强调的高维结论是：

- 高维 noisy two-scale 任务首次出现了 `slow_sindy_delta_rc` 的主导优势
- 说明“显式慢骨架 + 稳定 residual closure”在 hardest regime 下是有价值的

## 5. 消融实验结论

### 5.1 Fast/slow 与记忆结构消融

来源：`runs/highdim_fastslow_ablation`

主要发现：

1. `fast/slow` 特征不是普适增益。
   - 在 `lorenz96_k32_partial_noisy` 上，`rc_fastslow_readout` 反而明显差于 `rc_raw`
   - 在 `lorenz96_twoscale_k16_j4_noisy` 上，`rc_fastslow_readout` 则大幅优于 `rc_raw`

2. `NGRC` 并不会因为加了 fast/slow 特征就自动更稳。
   - 在 noisy chaotic 任务上略有提升
   - 在 noisy two-scale 任务上反而不如 `ngrc_raw`

3. `hybrid_rc_ngrc_fastslow` 改善了一部分 mismatch，但不是所有任务上的最优 `rmse@50` 模型。

结论：

- fast/slow 结构必须和真实 latent organization 对齐才有帮助
- “是否多尺度”比“是否高维”更决定 fast/slow 是否有效

### 5.2 Structured residual 消融

来源：`runs/highdim_structured_ablation`

主要发现：

1. 在 clean two-scale 高维任务上：
   - `hybrid_rc_ngrc_fastslow` 最优，`rmse@50 = 0.1572`

2. 在 noisy two-scale 高维任务上：
   - `slow_sindy_delta_rc` 最优，`rmse@50 = 0.4120`
   - `slow_sindy_delta_ngrc` 最优 `rmse@100 = 1.6754`
   - `slow_sindy_delta_hybrid` 最优 `rmse@10 = 0.0686`

这说明：

- 不同 residual closure 在不同 horizon 上各有优势
- 当前的 `slow_sindy_delta_hybrid` 已经体现出 short-horizon 和 mismatch 改善
- 但在 medium-horizon `rmse@50` 上还没有超过最强 baseline

## 6. 核心 insights

1. 目前最重要的结论是“模型选择必须 regime-aware”。
   - 不同任务族的最优模型不同，不能再用单一默认模型覆盖全部情况。

2. `one-step` 和 `rollout` 是两个不同问题。
   - `ngrc_fastslow_readout` 的中位 mismatch ratio 约为 `181.2`，是所有模型里最高的一档。
   - `slow_sindy_only` 的中位 mismatch 最低，但预测精度并不最好。

3. 显式结构不是越多越好。
   - 当结构和真实系统匹配时，它带来稳定性和可解释性收益。
   - 当结构不匹配时，反而会压制有效闭环记忆。

4. 当前最好用的经验法则：
   - 低维多尺度：`rc_fastslow_readout`
   - 低维混沌/noisy chaotic：`hybrid_rc_ngrc_fastslow`
   - 高维 chaotic：`hybrid_rc_ngrc_fastslow` 或 `ngrc_fastslow_readout`
   - 高维 noisy multiscale：`slow_sindy_delta_rc`

5. 新模型 `slow_sindy_delta_hybrid` 的价值已经出现，但还没有完全释放。
   - 它更像是一个“方向正确但还需进一步结构化”的候选项，而不是当前最终赢家。

## 7. 审稿人视角

### 7.1 优点

- 实验不再局限于低维 toy systems，已经覆盖更有说服力的高维 Lorenz-96 系列。
- 代码已经模块化到可以支持清晰的 direction-level ablation。
- 结果支持“什么时候该用结构，什么时候不该用”的细粒度论断，而不是空泛宣称。

### 7.2 风险点

1. 还没有外部深度序列 baseline。
   - 审稿人会质疑为什么不和至少一个现代 sequence model 比较。

2. 还没有 multi-seed 统计。
   - 目前所有结论仍然是单 seed 结果，强结论风险较大。

3. `slow_sindy_delta_hybrid` 还没成为 strongest method。
   - 现在更适合作为“新方向”而不是“最终主方法”。

4. 某些平均值受极端发散影响。
   - 例如 `rc_fastslow_readout` 在某个高维 chaotic 任务上 `rmse@100` 极大，说明报告里必须同时给出稳定性说明，不能只报均值。

### 7.3 建议论文表述

更稳妥的写法是：

- 本工作提出一个模块化结构化预测框架
- 重点贡献在于揭示了 fast/slow 读出、双记忆和 slow-backbone 在不同 regime 下的作用边界
- 而不是宣称一个单模型在所有任务上都最好

## 8. 下一步建议

### 8.1 最值得做的新方向

建议下一步做：

- `gated slow_sindy_delta_hybrid`

基本思想：

- 保留 `slow_sindy` backbone
- 保留 residual dual-memory closure
- 但引入一个 scale-aware / confidence-aware gating 机制
- 让模型在不同局部状态下动态决定更相信：
  - RC residual
  - NGRC residual
  - 或 slow backbone 的保守更新

### 8.2 理论动机

- 从 slow-fast decomposition 角度看，resolved slow manifold 应该显式建模。
- 从 memory-kernel / Mori-Zwanzig 角度看，unresolved dynamics 不应由单一 closure 在所有状态下统一处理。
- 因此“有骨架 + 有 closure + 有 gating”是比当前模型更自然的下一步。

### 8.3 实验优先级

建议按下面顺序推进：

1. 多 seed 重跑当前主实验
2. 增加 1 个外部深度 baseline
3. 实现 gated `slow_sindy_delta_hybrid`
4. 只在高维 multiscale 任务上做 targeted evaluation

## 9. 相关结果文件

- 低维主实验报告：
  - `runs/lowdim_common_research/analysis_report.md`
  - `runs/lowdim_hard_research/analysis_report.md`
- 高维主实验报告：
  - `runs/highdim_research/analysis_report.md`
- 主实验总表：
  - `runs/overall_main_research/analysis_report.md`
- 定向消融：
  - `runs/highdim_fastslow_ablation/analysis_report.md`
  - `runs/highdim_structured_ablation/analysis_report.md`
