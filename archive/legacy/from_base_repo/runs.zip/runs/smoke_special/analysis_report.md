# Result analysis

## Best model by task

### lorenz63_smoke
- best one_step_rmse: `slow_sindy_delta_ngrc` = 0.12871
- best rmse@10: `ngrc_fastslow_readout` = 0.0385938
- best rmse@50: `slow_sindy_delta_rc` = 2.30641
- best rmse@100: `slow_sindy_delta_rc` = 3.27655
- best acf_rmse: `rc_fastslow_readout` = 0.124347
- best psd_rmse: `slow_sindy_delta_ngrc` = 0.0940487

### vanderpol_smoke
- best one_step_rmse: `rc_fastslow_readout` = 1.8866e-05
- best rmse@10: `rc_fastslow_readout` = 0.000194734
- best rmse@50: `rc_fastslow_readout` = 0.000557644
- best rmse@100: `rc_fastslow_readout` = 0.000593437
- best acf_rmse: `rc_fastslow_readout` = 0.000399168
- best psd_rmse: `rc_fastslow_readout` = 0.000141873

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| hybrid_rc_ngrc_fastslow |       0.86015   | 0.453249  |   1.28856 |    4.51881 |  0.354782  |  0.0622021 |             133 |              133 |           4357 |         1.82029  |             593.096 |
| slow_sindy_delta_rc     |       0.175259  | 0.434484  |   2.30641 |    3.27655 |  0.405797  |  0.105854  |             246 |              252 |          58332 |         6.24618  |             387.532 |
| rc_fastslow_readout     |       0.0961702 | 0.409108  |   2.60237 |    3.95433 |  0.0623729 |  0.0486206 |             120 |              124 |          14764 |         0.544279 |             143.705 |
| slow_sindy_delta_ngrc   |       0.12871   | 0.196991  |   3.16911 |    3.61907 |  0.2064    |  0.0940487 |              76 |               76 |             76 |         4.51717  |             661.117 |
| ngrc_fastslow_readout   |       0.97913   | 0.0318877 |  13.7641  |   14.0271  |  0.728718  |  0.0960498 |              96 |               96 |             96 |         0.197871 |             729.642 |

## Parameter-aware notes

## Instability flags

| task            | variant                 |     rmse@10 |   rmse@50 |   rmse@100 |   effective_dim |   trained_params |
|:----------------|:------------------------|------------:|----------:|-----------:|----------------:|-----------------:|
| lorenz63_smoke  | ngrc_fastslow_readout   | 0.0385938   | 15.975    |   18.2632  |              69 |               69 |
| lorenz63_smoke  | slow_sindy_delta_ngrc   | 0.196991    |  3.16911  |    3.61907 |              76 |               76 |
| vanderpol_smoke | ngrc_fastslow_readout   | 0.0251817   | 11.5531   |    9.79097 |             123 |              123 |
| vanderpol_smoke | hybrid_rc_ngrc_fastslow | 0.000259067 |  0.171145 |    5.67055 |             133 |              133 |

## One-step vs long-horizon mismatch

| task            | variant                 |   one_step_rmse |      rmse@50 |   mismatch_ratio |   effective_dim |
|:----------------|:------------------------|----------------:|-------------:|-----------------:|----------------:|
| vanderpol_smoke | ngrc_fastslow_readout   |     4.03702e-05 | 11.5531      |     286179       |             123 |
| vanderpol_smoke | hybrid_rc_ngrc_fastslow |     4.00166e-05 |  0.171145    |       4276.86    |             133 |
| vanderpol_smoke | rc_fastslow_readout     |     1.8866e-05  |  0.000557644 |         29.5582  |             120 |
| lorenz63_smoke  | rc_fastslow_readout     |     0.192322    |  5.20418     |         27.0598  |             120 |
| lorenz63_smoke  | slow_sindy_delta_ngrc   |     0.12871     |  3.16911     |         24.6221  |              76 |
| lorenz63_smoke  | slow_sindy_delta_rc     |     0.175259    |  2.30641     |         13.16    |             246 |
| lorenz63_smoke  | ngrc_fastslow_readout   |     1.95822     | 15.975       |          8.15794 |              69 |
| lorenz63_smoke  | hybrid_rc_ngrc_fastslow |     1.72026     |  2.40597     |          1.39861 |             133 |
