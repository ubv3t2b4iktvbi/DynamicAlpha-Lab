# Result analysis

## Best model by task

### lorenz63_smoke
- best one_step_rmse: `slow_sindy_delta_ngrc` = 0.12871
- best rmse@10: `ngrc_fastslow_readout` = 0.0385938
- best rmse@50: `slow_sindy_delta_rc` = 2.29938
- best rmse@100: `slow_sindy_delta_rc` = 3.27408
- best acf_rmse: `rc_fastslow_readout` = 0.0903276
- best psd_rmse: `slow_sindy_only` = 0.0933196
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`clean_partial`

### vanderpol_smoke
- best one_step_rmse: `rc_fastslow_readout` = 1.99038e-05
- best rmse@10: `rc_fastslow_readout` = 0.00020513
- best rmse@50: `rc_fastslow_readout` = 0.000584949
- best rmse@100: `rc_fastslow_readout` = 0.000618028
- best acf_rmse: `rc_fastslow_readout` = 0.000427026
- best psd_rmse: `rc_fastslow_readout` = 0.000151402
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`clean_partial`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| hybrid_rc_ngrc_fastslow |       0.881221  | 0.423977  |   1.26871 |    4.39027 |  0.333071  |  0.059062  |             133 |              133 |           4357 |        3.44675   |             750.292 |
| slow_sindy_delta_rc     |       0.0886958 | 0.217268  |   1.35664 |    3.42208 |  0.233281  |  0.0688528 |             186 |              192 |          36552 |       14.7167    |             378.081 |
| slow_sindy_delta_ngrc   |       0.0663745 | 0.098622  |   1.7453  |    2.87038 |  0.340771  |  0.0710967 |              76 |               76 |             76 |        6.88971   |             734.782 |
| rc_fastslow_readout     |       0.0773297 | 0.242258  |   2.67698 |    4.06256 |  0.0453773 |  0.0523544 |             120 |              124 |          14764 |        2.18855   |             211.863 |
| slow_sindy_only         |       1.35637   | 1.09582   |   5.89834 |    9.27017 |  0.10589   |  0.0613371 |               6 |                6 |              6 |        0.0158922 |             188.402 |
| slow_sindy_delta_hybrid |       0.113149  | 0.400072  |   7.73101 |    8.84186 |  0.220809  |  0.0679132 |             140 |              140 |           4364 |       17.3417    |            1184.1   |
| ngrc_fastslow_readout   |       0.97913   | 0.0318877 |  13.7641  |   14.0271  |  0.728699  |  0.0960475 |              96 |               96 |             96 |        0.420025  |             751.369 |

## Family-wise averages

|                                                  |     rmse@10 |      rmse@50 |     rmse@100 |    acf_rmse |    psd_rmse |
|:-------------------------------------------------|------------:|-------------:|-------------:|------------:|------------:|
| ('lowdim_multiscale', 'rc_fastslow_readout')     | 0.00020513  |  0.000584949 |  0.000618028 | 0.000427026 | 0.000151402 |
| ('lowdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.00028025  |  0.123768    |  5.42036     | 0.305052    | 0.014103    |
| ('lowdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.000253324 |  0.321488    |  2.1217      | 0.475141    | 0.0481447   |
| ('lowdim_multiscale', 'slow_sindy_delta_hybrid') | 0.00063025  |  0.377114    |  3.11529     | 0.0656794   | 0.0323537   |
| ('lowdim_multiscale', 'slow_sindy_delta_rc')     | 0.00175974  |  0.413896    |  3.57008     | 0.0610234   | 0.0318277   |
| ('lowdim_multiscale', 'slow_sindy_only')         | 0.00929904  |  0.466102    |  3.45674     | 0.0532745   | 0.0293545   |
| ('lowdim_chaotic', 'slow_sindy_delta_rc')        | 0.432776    |  2.29938     |  3.27408     | 0.405539    | 0.105878    |
| ('lowdim_chaotic', 'hybrid_rc_ngrc_fastslow')    | 0.847674    |  2.41366     |  3.36019     | 0.36109     | 0.104021    |
| ('lowdim_chaotic', 'slow_sindy_delta_ngrc')      | 0.196991    |  3.16911     |  3.61907     | 0.2064      | 0.0940487   |
| ('lowdim_chaotic', 'rc_fastslow_readout')        | 0.484311    |  5.35337     |  8.12451     | 0.0903276   | 0.104557    |
| ('lowdim_chaotic', 'slow_sindy_only')            | 2.18233     | 11.3306      | 15.0836      | 0.158505    | 0.0933196   |
| ('lowdim_multiscale', 'ngrc_fastslow_readout')   | 0.0251816   | 11.5531      |  9.79099     | 0.787457    | 0.0768559   |
| ('lowdim_chaotic', 'slow_sindy_delta_hybrid')    | 0.799513    | 15.0849      | 14.5684      | 0.375939    | 0.103473    |
| ('lowdim_chaotic', 'ngrc_fastslow_readout')      | 0.0385938   | 15.975       | 18.2632      | 0.66994     | 0.115239    |

## Dimension scaling

|   state_dim | variant                 |      rmse@50 |     rmse@100 |   one_step_rmse |
|------------:|:------------------------|-------------:|-------------:|----------------:|
|           2 | rc_fastslow_readout     |  0.000584949 |  0.000618028 |     1.99038e-05 |
|           2 | hybrid_rc_ngrc_fastslow |  0.123768    |  5.42036     |     4.23104e-05 |
|           2 | slow_sindy_delta_ngrc   |  0.321488    |  2.1217      |     0.00403865  |
|           2 | slow_sindy_delta_hybrid |  0.377114    |  3.11529     |     0.00402248  |
|           2 | slow_sindy_delta_rc     |  0.413896    |  3.57008     |     0.00241713  |
|           2 | slow_sindy_only         |  0.466102    |  3.45674     |     0.151114    |
|           2 | ngrc_fastslow_readout   | 11.5531      |  9.79099     |     4.03702e-05 |
|           3 | slow_sindy_delta_rc     |  2.29938     |  3.27408     |     0.174975    |
|           3 | hybrid_rc_ngrc_fastslow |  2.41366     |  3.36019     |     1.7624      |
|           3 | slow_sindy_delta_ngrc   |  3.16911     |  3.61907     |     0.12871     |
|           3 | rc_fastslow_readout     |  5.35337     |  8.12451     |     0.15464     |
|           3 | slow_sindy_only         | 11.3306      | 15.0836      |     2.56162     |
|           3 | slow_sindy_delta_hybrid | 15.0849      | 14.5684      |     0.222276    |
|           3 | ngrc_fastslow_readout   | 15.975       | 18.2632      |     1.95822     |

### Best variant per state dimension
|   state_dim | best_variant        |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:--------------------|-------------:|-------------:|--------------:|
|           2 | rc_fastslow_readout |            1 |  0.000584949 |   0.000618028 |
|           3 | slow_sindy_delta_rc |            1 |  2.29938     |   3.27408     |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| dual_memory_vs_single_memory     | rc_fastslow_readout     | hybrid_rc_ngrc_fastslow |       2 |           1.40826 |          -0.327708 |               -1431.3    | Combining recurrent and delay memories should improve horizon balance.  |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |       2 |          -5.98571 |          -5.97148  |                 -28.6963 | Adding reservoir memory should stabilize residual NGRC rollouts.        |
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |       2 |          -6.4623  |          -4.45159  |                1382.49   | A slow-manifold prior should help on multiscale high-dimensional tasks. |

## One-step vs long-horizon mismatch

| task            | variant                 |   one_step_rmse |      rmse@50 |   mismatch_ratio |   state_dim |
|:----------------|:------------------------|----------------:|-------------:|-----------------:|------------:|
| vanderpol_smoke | ngrc_fastslow_readout   |     4.03702e-05 | 11.5531      |     286179       |           2 |
| vanderpol_smoke | hybrid_rc_ngrc_fastslow |     4.23104e-05 |  0.123768    |       2925.24    |           2 |
| vanderpol_smoke | slow_sindy_delta_rc     |     0.00241713  |  0.413896    |        171.235   |           2 |
| vanderpol_smoke | slow_sindy_delta_hybrid |     0.00402248  |  0.377114    |         93.7518  |           2 |
| vanderpol_smoke | slow_sindy_delta_ngrc   |     0.00403865  |  0.321488    |         79.6028  |           2 |
| lorenz63_smoke  | slow_sindy_delta_hybrid |     0.222276    | 15.0849      |         67.8657  |           3 |
| lorenz63_smoke  | rc_fastslow_readout     |     0.15464     |  5.35337     |         34.6184  |           3 |
| vanderpol_smoke | rc_fastslow_readout     |     1.99038e-05 |  0.000584949 |         29.3888  |           2 |
| lorenz63_smoke  | slow_sindy_delta_ngrc   |     0.12871     |  3.16911     |         24.6221  |           3 |
| lorenz63_smoke  | slow_sindy_delta_rc     |     0.174975    |  2.29938     |         13.1412  |           3 |
| lorenz63_smoke  | ngrc_fastslow_readout   |     1.95822     | 15.975       |          8.15794 |           3 |
| lorenz63_smoke  | slow_sindy_only         |     2.56162     | 11.3306      |          4.4232  |           3 |
| vanderpol_smoke | slow_sindy_only         |     0.151114    |  0.466102    |          3.08445 |           2 |
| lorenz63_smoke  | hybrid_rc_ngrc_fastslow |     1.7624      |  2.41366     |          1.36953 |           3 |

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `slow_sindy_delta_rc` is only the most frequent winner, not a universal winner.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
