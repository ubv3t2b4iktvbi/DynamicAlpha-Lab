# Result analysis

## Best model by task

### lorenz96_twoscale_k12_j6
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000111999
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.00127805
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 0.157153
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 1.09592
- best acf_rmse: `slow_sindy_only` = 0.00912878
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 0.0226461
- metadata: state_dim=84, family=`highdim_multiscale`, regime=`dimension_scaling`

### lorenz96_twoscale_k16_j4_noisy
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.0286824
- best rmse@10: `slow_sindy_delta_hybrid` = 0.0686112
- best rmse@50: `slow_sindy_delta_rc` = 0.411986
- best rmse@100: `slow_sindy_delta_ngrc` = 1.67543
- best acf_rmse: `hybrid_rc_ngrc_fastslow` = 0.0407473
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 0.0225024
- metadata: state_dim=80, family=`highdim_multiscale`, regime=`dimension_scaling_noisy`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| slow_sindy_delta_rc     |       0.02371   | 0.0577408 |  0.796353 |    3.64306 |  0.0697192 |  0.0492054 |             186 |              192 |          36552 |       51.186     |             843.148 |
| slow_sindy_only         |       1.27702   | 0.920339  |  0.868607 |    2.04177 |  0.0467765 |  0.0421041 |               6 |                6 |              6 |        0.0469343 |             558.735 |
| slow_sindy_delta_ngrc   |       0.0248871 | 0.0671419 |  0.960476 |    2.71032 |  0.0805591 |  0.0305164 |             103 |              103 |            103 |       44.5332    |            2863.82  |
| slow_sindy_delta_hybrid |       0.0255869 | 0.0607169 |  1.0627   |    3.66537 |  0.0320415 |  0.0404479 |             250 |              250 |          14890 |       99.9153    |            3732.69  |
| hybrid_rc_ngrc_fastslow |       0.0143972 | 0.0763932 |  1.28725  |    2.2251  |  0.0767085 |  0.0225743 |             133 |              133 |           4357 |       19.5482    |            2357.71  |

## Family-wise averages

|                                                   |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |
|:--------------------------------------------------|----------:|----------:|-----------:|-----------:|-----------:|
| ('highdim_multiscale', 'slow_sindy_delta_rc')     | 0.0577408 |  0.796353 |    3.64306 |  0.0697192 |  0.0492054 |
| ('highdim_multiscale', 'slow_sindy_only')         | 0.920339  |  0.868607 |    2.04177 |  0.0467765 |  0.0421041 |
| ('highdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.0671419 |  0.960476 |    2.71032 |  0.0805591 |  0.0305164 |
| ('highdim_multiscale', 'slow_sindy_delta_hybrid') | 0.0607169 |  1.0627   |    3.66537 |  0.0320415 |  0.0404479 |
| ('highdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.0763932 |  1.28725  |    2.2251  |  0.0767085 |  0.0225743 |

## Dimension scaling

|   state_dim | variant                 |   rmse@50 |   rmse@100 |   one_step_rmse |
|------------:|:------------------------|----------:|-----------:|----------------:|
|          80 | slow_sindy_delta_rc     |  0.411986 |    2.12565 |     0.0328985   |
|          80 | slow_sindy_delta_ngrc   |  0.513219 |    1.67543 |     0.0414965   |
|          80 | slow_sindy_delta_hybrid |  0.863537 |    3.31852 |     0.0304876   |
|          80 | slow_sindy_only         |  1.03477  |    2.17174 |     1.40376     |
|          80 | hybrid_rc_ngrc_fastslow |  2.41734  |    3.35427 |     0.0286824   |
|          84 | hybrid_rc_ngrc_fastslow |  0.157153 |    1.09592 |     0.000111999 |
|          84 | slow_sindy_only         |  0.702443 |    1.9118  |     1.15028     |
|          84 | slow_sindy_delta_rc     |  1.18072  |    5.16047 |     0.0145215   |
|          84 | slow_sindy_delta_hybrid |  1.26185  |    4.01222 |     0.0206862   |
|          84 | slow_sindy_delta_ngrc   |  1.40773  |    3.74522 |     0.00827781  |

### Best variant per state dimension
|   state_dim | best_variant            |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:------------------------|-------------:|-------------:|--------------:|
|          80 | slow_sindy_delta_rc     |            1 |     0.411986 |       2.12565 |
|          84 | hybrid_rc_ngrc_fastslow |            1 |     0.157153 |       1.09592 |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |       2 |          0.224553 |          -1.44027  |                 699.061  | A slow-manifold prior should help on multiscale high-dimensional tasks. |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |       2 |         -0.102219 |          -0.955048 |                  46.5523 | Adding reservoir memory should stabilize residual NGRC rollouts.        |

## One-step vs long-horizon mismatch

| task                           | variant                 |   one_step_rmse |   rmse@50 |   mismatch_ratio |   state_dim |
|:-------------------------------|:------------------------|----------------:|----------:|-----------------:|------------:|
| lorenz96_twoscale_k12_j6       | hybrid_rc_ngrc_fastslow |     0.000111999 |  0.157153 |      1403.17     |          84 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_ngrc   |     0.00827781  |  1.40773  |       170.061    |          84 |
| lorenz96_twoscale_k16_j4_noisy | hybrid_rc_ngrc_fastslow |     0.0286824   |  2.41734  |        84.2796   |          80 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_rc     |     0.0145215   |  1.18072  |        81.3083   |          84 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_hybrid |     0.0206862   |  1.26185  |        60.9999   |          84 |
| lorenz96_twoscale_k16_j4_noisy | slow_sindy_delta_hybrid |     0.0304876   |  0.863537 |        28.3243   |          80 |
| lorenz96_twoscale_k16_j4_noisy | slow_sindy_delta_rc     |     0.0328985   |  0.411986 |        12.523    |          80 |
| lorenz96_twoscale_k16_j4_noisy | slow_sindy_delta_ngrc   |     0.0414965   |  0.513219 |        12.3678   |          80 |
| lorenz96_twoscale_k16_j4_noisy | slow_sindy_only         |     1.40376     |  1.03477  |         0.737141 |          80 |
| lorenz96_twoscale_k12_j6       | slow_sindy_only         |     1.15028     |  0.702443 |         0.610669 |          84 |

## Insights

- Injecting a slow SINDy backbone helps when the task family is genuinely multiscale or high-dimensional, which matches the idea that an explicit resolved slow manifold stabilizes forecasting.
- The new slow-SINDy delta hybrid reduces residual-model mismatch relative to pure NGRC closure, suggesting that residual dynamics also benefit from recurrent state regularization.
- On the current high-dimensional tasks, `hybrid_rc_ngrc_fastslow` wins most often, so claims should be framed around partial-observation structure rather than universal dominance.

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Current signal: `slow_sindy_delta_hybrid` is already implemented in this revision, so the new hypothesis is directly testable; its current average high-dimensional `rmse@50` is 1.063.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `hybrid_rc_ngrc_fastslow` is only the most frequent winner, not a universal winner.
- Strength: the updated suite now includes higher-dimensional Lorenz-96 scaling tasks, which makes the evaluation less vulnerable to the criticism that the benchmark is only low-dimensional.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
