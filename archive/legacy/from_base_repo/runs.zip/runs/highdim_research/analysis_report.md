# Result analysis

## Best model by task

### lorenz96_k16_partial
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000946721
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.0216341
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 1.13792
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.858179
- best acf_rmse: `rc_fastslow_readout` = 0.0471755
- best psd_rmse: `rc_fastslow_readout` = 0.00965695
- metadata: state_dim=16, family=`highdim_chaotic`, regime=`dimension_scaling`

### lorenz96_k32_partial
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000531059
- best rmse@10: `ngrc_fastslow_readout` = 0.010395
- best rmse@50: `ngrc_fastslow_readout` = 0.854362
- best rmse@100: `ngrc_fastslow_readout` = 2.08106
- best acf_rmse: `slow_sindy_only` = 0.0136325
- best psd_rmse: `slow_sindy_only` = 0.0154424
- metadata: state_dim=32, family=`highdim_chaotic`, regime=`dimension_scaling`

### lorenz96_k32_partial_noisy
- best one_step_rmse: `ngrc_fastslow_readout` = 0.0347783
- best rmse@10: `rc_fastslow_readout` = 0.0385224
- best rmse@50: `ngrc_fastslow_readout` = 1.71293
- best rmse@100: `ngrc_fastslow_readout` = 4.18927
- best acf_rmse: `slow_sindy_only` = 0.137964
- best psd_rmse: `slow_sindy_only` = 0.0205726
- metadata: state_dim=32, family=`highdim_chaotic`, regime=`dimension_scaling_noisy`

### lorenz96_twoscale_k12_j6
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000112048
- best rmse@10: `rc_fastslow_readout` = 0.00113637
- best rmse@50: `rc_fastslow_readout` = 0.117645
- best rmse@100: `rc_fastslow_readout` = 0.147832
- best acf_rmse: `slow_sindy_only` = 0.00912878
- best psd_rmse: `rc_fastslow_readout` = 0.0181788
- metadata: state_dim=84, family=`highdim_multiscale`, regime=`dimension_scaling`

### lorenz96_twoscale_k16_j4_noisy
- best one_step_rmse: `ngrc_fastslow_readout` = 0.0281151
- best rmse@10: `ngrc_fastslow_readout` = 0.0670569
- best rmse@50: `slow_sindy_delta_rc` = 0.413621
- best rmse@100: `rc_fastslow_readout` = 1.264
- best acf_rmse: `slow_sindy_delta_hybrid` = 0.00992637
- best psd_rmse: `rc_fastslow_readout` = 0.0110511
- metadata: state_dim=80, family=`highdim_multiscale`, regime=`dimension_scaling_noisy`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |    rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|------------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| ngrc_fastslow_readout   |       0.013886  | 0.0591814 |   1.67257 | 4.78433     |   0.243167 |  0.0411817 |           167.4 |            167.4 |          167.4 |        1.75548   |            3399.09  |
| slow_sindy_only         |       1.6269    | 0.912986  |   1.69117 | 2.70372     |   0.100081 |  0.0290778 |             6   |              6   |            6   |        0.0511512 |             470.121 |
| hybrid_rc_ngrc_fastslow |       0.0132431 | 0.091598  |   1.80187 | 3.55241     |   0.211169 |  0.033087  |           155   |            155   |         6462.2 |       23.0127    |            2482.11  |
| slow_sindy_delta_rc     |       0.0523593 | 0.497447  |   2.03818 | 4.97921     |   0.27491  |  0.0540198 |           198   |            204   |        40908   |       60.0809    |            1188.33  |
| slow_sindy_delta_ngrc   |       0.0442232 | 0.53204   |   2.64484 | 4.61093     |   0.156816 |  0.0522311 |            97.6 |             97.6 |           97.6 |       56.0493    |            3292.84  |
| slow_sindy_delta_hybrid |       0.0443741 | 0.523096  |   2.66337 | 4.08433     |   0.165016 |  0.0507789 |           228   |            228   |        12784.8 |      132.264     |            3888.51  |
| rc_fastslow_readout     |       0.0185158 | 0.198443  |   3.14284 | 1.66042e+06 |   0.322522 |  0.0326098 |           168   |            172   |        32188   |        5.38455   |             530.93  |

## Family-wise averages

|                                                   |   rmse@10 |   rmse@50 |    rmse@100 |   acf_rmse |   psd_rmse |
|:--------------------------------------------------|----------:|----------:|------------:|-----------:|-----------:|
| ('highdim_multiscale', 'rc_fastslow_readout')     | 0.0500597 |  0.321153 | 0.705914    |  0.0201885 |  0.0146149 |
| ('highdim_multiscale', 'ngrc_fastslow_readout')   | 0.0347535 |  0.607559 | 1.95853     |  0.0354242 |  0.0237392 |
| ('highdim_multiscale', 'slow_sindy_delta_rc')     | 0.0731823 |  0.86204  | 4.01769     |  0.0613108 |  0.0472393 |
| ('highdim_multiscale', 'slow_sindy_only')         | 0.920339  |  0.868607 | 2.04177     |  0.0467765 |  0.0421041 |
| ('highdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.0671419 |  0.960476 | 2.71032     |  0.0805591 |  0.0305164 |
| ('highdim_multiscale', 'slow_sindy_delta_hybrid') | 0.0686819 |  0.995865 | 3.69361     |  0.013575  |  0.0455752 |
| ('highdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.0758038 |  1.24587  | 2.15648     |  0.0321433 |  0.0354055 |
| ('highdim_chaotic', 'hybrid_rc_ngrc_fastslow')    | 0.102127  |  2.17253  | 4.48303     |  0.33052   |  0.0315413 |
| ('highdim_chaotic', 'slow_sindy_only')            | 0.908084  |  2.23954  | 3.14502     |  0.135617  |  0.0203937 |
| ('highdim_chaotic', 'ngrc_fastslow_readout')      | 0.0754667 |  2.38258  | 6.6682      |  0.381662  |  0.0528101 |
| ('highdim_chaotic', 'slow_sindy_delta_rc')        | 0.780291  |  2.82227  | 5.62022     |  0.417309  |  0.0585402 |
| ('highdim_chaotic', 'slow_sindy_delta_ngrc')      | 0.841973  |  3.76775  | 5.87799     |  0.207655  |  0.0667076 |
| ('highdim_chaotic', 'slow_sindy_delta_hybrid')    | 0.826039  |  3.77505  | 4.34481     |  0.265976  |  0.054248  |
| ('highdim_chaotic', 'rc_fastslow_readout')        | 0.297365  |  5.02397  | 2.76736e+06 |  0.524077  |  0.0446063 |

## Dimension scaling

|   state_dim | variant                 |   rmse@50 |     rmse@100 |   one_step_rmse |
|------------:|:------------------------|----------:|-------------:|----------------:|
|          16 | hybrid_rc_ngrc_fastslow |  1.13792  |  0.858179    |     0.000946721 |
|          16 | slow_sindy_only         |  1.59643  |  2.38328     |     1.94644     |
|          16 | rc_fastslow_readout     |  2.89264  |  5.05788     |     0.00669627  |
|          16 | slow_sindy_delta_rc     |  4.41886  |  3.56199     |     0.0759896   |
|          16 | ngrc_fastslow_readout   |  4.58045  | 13.7343      |     0.00410828  |
|          16 | slow_sindy_delta_hybrid |  6.44854  |  5.71754     |     0.0748252   |
|          16 | slow_sindy_delta_ngrc   |  6.72737  |  8.7971      |     0.07477     |
|          32 | ngrc_fastslow_readout   |  1.28364  |  3.13516     |     0.0184898   |
|          32 | slow_sindy_delta_rc     |  2.02397  |  6.64933     |     0.0661164   |
|          32 | slow_sindy_delta_ngrc   |  2.28793  |  4.41844     |     0.0482859   |
|          32 | slow_sindy_delta_hybrid |  2.4383   |  3.65844     |     0.0479077   |
|          32 | slow_sindy_only         |  2.56109  |  3.5259      |     1.81702     |
|          32 | hybrid_rc_ngrc_fastslow |  2.68984  |  6.29546     |     0.0182342   |
|          32 | rc_fastslow_readout     |  6.08963  |  4.15104e+06 |     0.0284419   |
|          80 | slow_sindy_delta_rc     |  0.413621 |  2.11099     |     0.0328969   |
|          80 | slow_sindy_delta_ngrc   |  0.513219 |  1.67543     |     0.0414965   |
|          80 | rc_fastslow_readout     |  0.524661 |  1.264       |     0.0288703   |
|          80 | ngrc_fastslow_readout   |  0.724479 |  1.66833     |     0.0281151   |
|          80 | slow_sindy_delta_hybrid |  0.728483 |  3.37504     |     0.0305442   |
|          80 | slow_sindy_only         |  1.03477  |  2.17174     |     1.40376     |
|          80 | hybrid_rc_ngrc_fastslow |  2.34561  |  3.23928     |     0.0286885   |
|          84 | rc_fastslow_readout     |  0.117645 |  0.147832    |     0.000128674 |
|          84 | hybrid_rc_ngrc_fastslow |  0.146139 |  1.07369     |     0.000112048 |
|          84 | ngrc_fastslow_readout   |  0.490639 |  2.24872     |     0.000227163 |
|          84 | slow_sindy_only         |  0.702443 |  1.9118      |     1.15028     |
|          84 | slow_sindy_delta_hybrid |  1.26325  |  4.01219     |     0.0206856   |
|          84 | slow_sindy_delta_rc     |  1.31046  |  5.9244      |     0.0206776   |
|          84 | slow_sindy_delta_ngrc   |  1.40773  |  3.74522     |     0.00827781  |

### Best variant per state dimension
|   state_dim | best_variant            |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:------------------------|-------------:|-------------:|--------------:|
|          16 | hybrid_rc_ngrc_fastslow |            1 |     1.13792  |      0.858179 |
|          32 | ngrc_fastslow_readout   |            2 |     1.28364  |      3.13516  |
|          80 | slow_sindy_delta_rc     |            1 |     0.413621 |      2.11099  |
|          84 | rc_fastslow_readout     |            1 |     0.117645 |      0.147832 |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| dual_memory_vs_single_memory     | rc_fastslow_readout     | hybrid_rc_ngrc_fastslow |       5 |         1.34097   |        1.66041e+06 |                -853.003  | Combining recurrent and delay memories should improve horizon balance.  |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |       5 |        -0.0185372 |        0.526597    |                  18.7943 | Adding reservoir memory should stabilize residual NGRC rollouts.        |
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |       5 |        -0.861505  |       -0.531915    |                1166.73   | A slow-manifold prior should help on multiscale high-dimensional tasks. |

## One-step vs long-horizon mismatch

| task                           | variant                 |   one_step_rmse |   rmse@50 |   mismatch_ratio |   state_dim |
|:-------------------------------|:------------------------|----------------:|----------:|-----------------:|------------:|
| lorenz96_k32_partial           | hybrid_rc_ngrc_fastslow |     0.000531059 |  1.81643  |        3420.4    |          32 |
| lorenz96_twoscale_k12_j6       | ngrc_fastslow_readout   |     0.000227163 |  0.490639 |        2159.85   |          84 |
| lorenz96_twoscale_k12_j6       | hybrid_rc_ngrc_fastslow |     0.000112048 |  0.146139 |        1304.25   |          84 |
| lorenz96_k16_partial           | hybrid_rc_ngrc_fastslow |     0.000946721 |  1.13792  |        1201.96   |          16 |
| lorenz96_k16_partial           | ngrc_fastslow_readout   |     0.00410828  |  4.58045  |        1114.93   |          16 |
| lorenz96_twoscale_k12_j6       | rc_fastslow_readout     |     0.000128674 |  0.117645 |         914.287  |          84 |
| lorenz96_k16_partial           | rc_fastslow_readout     |     0.00669627  |  2.89264  |         431.979  |          16 |
| lorenz96_k32_partial           | ngrc_fastslow_readout   |     0.00220129  |  0.854362 |         388.12   |          32 |
| lorenz96_k32_partial           | rc_fastslow_readout     |     0.0161968   |  4.80935  |         296.932  |          32 |
| lorenz96_k32_partial_noisy     | rc_fastslow_readout     |     0.040687    |  7.3699   |         181.136  |          32 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_ngrc   |     0.00827781  |  1.40773  |         170.061  |          84 |
| lorenz96_k32_partial_noisy     | hybrid_rc_ngrc_fastslow |     0.0359373   |  3.56325  |          99.1518 |          32 |
| lorenz96_k16_partial           | slow_sindy_delta_ngrc   |     0.07477     |  6.72737  |          89.9742 |          16 |
| lorenz96_k16_partial           | slow_sindy_delta_hybrid |     0.0748252   |  6.44854  |          86.1814 |          16 |
| lorenz96_twoscale_k16_j4_noisy | hybrid_rc_ngrc_fastslow |     0.0286885   |  2.34561  |          81.7612 |          80 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_rc     |     0.0206776   |  1.31046  |          63.3758 |          84 |
| lorenz96_twoscale_k12_j6       | slow_sindy_delta_hybrid |     0.0206856   |  1.26325  |          61.0691 |          84 |
| lorenz96_k32_partial_noisy     | slow_sindy_delta_hybrid |     0.0450418   |  2.68463  |          59.6031 |          32 |
| lorenz96_k16_partial           | slow_sindy_delta_rc     |     0.0759896   |  4.41886  |          58.1509 |          16 |
| lorenz96_k32_partial_noisy     | slow_sindy_delta_ngrc   |     0.0457852   |  2.48451  |          54.2645 |          32 |

## Insights

- The new slow-SINDy delta hybrid reduces residual-model mismatch relative to pure NGRC closure, suggesting that residual dynamics also benefit from recurrent state regularization.
- On the current high-dimensional tasks, `ngrc_fastslow_readout` wins most often, so claims should be framed around partial-observation structure rather than universal dominance.

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Current signal: `slow_sindy_delta_hybrid` is already implemented in this revision, so the new hypothesis is directly testable; its current average high-dimensional `rmse@50` is 2.663.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `ngrc_fastslow_readout` is only the most frequent winner, not a universal winner.
- Strength: the updated suite now includes higher-dimensional Lorenz-96 scaling tasks, which makes the evaluation less vulnerable to the criticism that the benchmark is only low-dimensional.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
