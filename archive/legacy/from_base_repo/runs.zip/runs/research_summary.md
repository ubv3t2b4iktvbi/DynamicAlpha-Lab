# Research summary

## What was added

- A new `highdim` suite with five higher-dimensional Lorenz-96 style tasks.
- Task metadata for `task_family`, `task_regime`, and `state_dim`.
- Reusable model groups plus `--tasks` filtering for targeted ablations.
- A new model candidate: `slow_sindy_delta_hybrid`.

## High-dimensional main results

Source: `runs/highdim_research/benchmark_results.csv`

- `lorenz96_k16_partial`:
  - best `rmse@50`: `hybrid_rc_ngrc_fastslow` = `1.1379`
  - best `rmse@100`: `hybrid_rc_ngrc_fastslow` = `0.8582`
- `lorenz96_k32_partial`:
  - best `rmse@50`: `ngrc_fastslow_readout` = `0.8544`
- `lorenz96_k32_partial_noisy`:
  - best `rmse@50`: `ngrc_fastslow_readout` = `1.7129`
- `lorenz96_twoscale_k12_j6`:
  - best `rmse@50`: `rc_fastslow_readout` = `0.1176`
- `lorenz96_twoscale_k16_j4_noisy`:
  - best `rmse@50`: `slow_sindy_delta_rc` = `0.4136`

Cross-task average `rmse@50` on the full high-dimensional suite:

- `ngrc_fastslow_readout`: `1.6726`
- `slow_sindy_only`: `1.6912`
- `hybrid_rc_ngrc_fastslow`: `1.8019`
- `slow_sindy_delta_rc`: `2.0382`
- `slow_sindy_delta_ngrc`: `2.6448`
- `slow_sindy_delta_hybrid`: `2.6634`
- `rc_fastslow_readout`: `3.1428`

## Targeted ablation 1: raw vs fast/slow vs dual memory

Source: `runs/highdim_fastslow_ablation/analysis_report.md`

Tasks:

- `lorenz96_k32_partial_noisy`
- `lorenz96_twoscale_k16_j4_noisy`

Key observations:

- On the noisy chaotic task, `ngrc_fastslow_readout` slightly beats `ngrc_raw` on `rmse@50` (`1.7129` vs `1.8634`).
- On the noisy two-scale task, `ngrc_raw` is the strongest model by a clear margin on `rmse@50` (`0.2920`), beating both `ngrc_fastslow_readout` (`0.7245`) and `rc_fastslow_readout` (`0.5247`).
- `rc_fastslow_readout` helps massively over `rc_raw` on the two-scale task (`0.5247` vs `2.9957`), but hurts badly on the noisy chaotic task (`7.3699` vs `3.7212`).
- `hybrid_rc_ngrc_fastslow` reduces the average mismatch ratio relative to `rc_fastslow_readout`, but it is not the best `rmse@50` model on these two tasks.

Takeaway:

- Fast/slow readout is not a universally positive inductive bias.
- RC benefits from it mainly in clearly multiscale settings.
- NGRC already captures enough local geometry on some tasks, and extra coarse features can become noise instead of help.

## Targeted ablation 2: structured multiscale models

Source: `runs/highdim_structured_ablation/analysis_report.md`

Tasks:

- `lorenz96_twoscale_k12_j6`
- `lorenz96_twoscale_k16_j4_noisy`

Key observations:

- Clean two-scale task:
  - best `rmse@50`: `hybrid_rc_ngrc_fastslow` = `0.1572`
  - `slow_sindy_only` gives very strong distributional statistics but weaker forecast accuracy (`rmse@50 = 0.7024`)
- Noisy two-scale task:
  - best `rmse@50`: `slow_sindy_delta_rc` = `0.4120`
  - best `rmse@10`: `slow_sindy_delta_hybrid` = `0.0686`
  - best `rmse@100`: `slow_sindy_delta_ngrc` = `1.6754`

Takeaway:

- Explicit slow structure matters more once the task becomes noisy and multiscale.
- The best closure depends on horizon:
  - RC residual closure is strongest at medium horizon.
  - NGRC residual closure helps longer horizon on the noisy two-scale case.
  - The new hybrid residual closure improves short-horizon accuracy and mismatch, but does not yet dominate `rmse@50`.

## Consolidated insights

1. There is no single best model family.
   - The winner changes across `state_dim`, noise level, and whether the task is single-scale chaotic or truly two-scale.

2. Short-horizon accuracy and free-rollout stability are different problems.
   - NGRC-style models are often excellent at one-step and short rollout, but can still show large mismatch ratios.

3. Fast/slow features help only when they align with the actual latent structure.
   - They are valuable in two-scale settings, but can be neutral or harmful in noisy single-scale chaotic settings.

4. Slow SINDy is a useful structural prior, not a complete solution by itself.
   - `slow_sindy_only` often gives good low-order statistics, but it needs a learned closure for competitive forecast error.

5. The best current structured model is `slow_sindy_delta_rc` on the hardest noisy two-scale task.
   - This suggests that residual stability matters more than maximal feature richness in that regime.

6. The new `slow_sindy_delta_hybrid` is promising as a concept, but not yet the top `rmse@50` model.
   - Its current value is mainly in reducing mismatch relative to pure NGRC residual closure.

## Theory-motivated next direction

Proposed next direction:

- Keep the slow SINDy backbone.
- Replace the current ungated residual hybrid with a scale-aware or confidence-weighted hybrid closure.

Theory rationale:

- Under slow-fast decomposition, the resolved slow manifold should be modeled explicitly.
- Under memory-kernel reasoning, unresolved effects should not be treated identically in all regimes.
- A gating rule can decide when to trust recurrent memory, delay memory, or slow residual updates.

Concrete experiment:

- Compare:
  - `hybrid_rc_ngrc_fastslow`
  - `slow_sindy_delta_rc`
  - `slow_sindy_delta_ngrc`
  - `slow_sindy_delta_hybrid`
  - a future gated version of `slow_sindy_delta_hybrid`
- Use only:
  - `lorenz96_twoscale_k12_j6`
  - `lorenz96_twoscale_k16_j4_noisy`
- Report:
  - `rmse@10`
  - `rmse@50`
  - `rmse@100`
  - mismatch ratio
  - `acf_rmse`
  - `psd_rmse`

## Reviewer-style assessment

Strengths:

- The benchmark is now meaningfully stronger because it includes higher-dimensional tasks.
- The code path is more modular: suites, model groups, and task filters now support clean ablations.
- The study now supports a credible claim about when structure helps and when it does not.

Weaknesses:

- The benchmark still lacks external deep-sequence baselines.
- Most conclusions are from a single seed.
- The new hybrid residual model does not yet outperform the strongest existing structured baseline on the key medium-horizon metric.
- Some claims would still be too strong if framed as universal superiority.

Recommended paper positioning:

- Frame the method as a structured forecasting framework for scalar partial observation.
- Emphasize regime dependence and modular evidence.
- Avoid universal SOTA language unless multi-seed and external baseline comparisons are added.
