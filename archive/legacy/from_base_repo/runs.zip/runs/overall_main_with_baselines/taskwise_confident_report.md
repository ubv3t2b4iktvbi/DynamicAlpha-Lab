# Taskwise Baseline Analysis

## Scope

This report supplements the main experiments with the missing `rc_raw` and `ngrc_raw` baselines, then analyzes results task by task instead of relying on overall averages.

Compared runs:

- `lowdim_common_research`
- `lowdim_hard_research`
- `highdim_research`
- `lowdim_common_baselines`
- `lowdim_hard_baselines`
- `highdim_baselines`

Primary metric below is `rmse@50`, with `rmse@100`, `one_step_rmse`, and mismatch behavior used to explain why a model wins or fails.

## What Changed After Adding Raw Baselines

The raw baselines are not weak controls. After adding them back:

- `rc_raw` wins `3/12` tasks.
- `ngrc_raw` wins `2/12` tasks.
- `ngrc_fastslow_readout` wins `3/12` tasks.
- `rc_fastslow_readout` wins `2/12` tasks.
- `hybrid_rc_ngrc_fastslow` wins `2/12` tasks.
- No structured SINDy residual model wins any task in the current single-seed main table.

This immediately changes the strength of our claims: the current evidence supports regime-dependent advantages, not universal superiority of the structured models.

## Low-Dimensional Chaotic Tasks

### `lorenz63_clean`

- Best model: `rc_fastslow_readout`, `rmse@50 = 0.2372`.
- Runner-up: `rc_raw`, `rmse@50 = 1.0553`.
- Important detail: `rc_raw` has much smaller `one_step_rmse` (`0.0006` vs `0.0026`) but much worse rollout error.

Interpretation:

- This is a textbook teacher-forcing versus free-rollout split.
- Pure RC can fit the next step extremely well, but its latent state is not organized enough to support long chaotic rollout under scalar partial observation.
- Adding the fast/slow readout features gives the linear readout access to coarse trend information from the scalar signal, which sharply reduces rollout mismatch.

Why this is credible:

- The gain is large, not marginal: `0.2372` vs `1.0553`, about a `4.45x` improvement at `rmse@50`.
- Both models are in the same RC family, so the difference is tied to the readout structure rather than a totally different modeling paradigm.

Confidence:

- High confidence that fast/slow readout helps RC on clean low-dimensional chaotic partial observation.

### `lorenz63_noisy`

- Best model: `hybrid_rc_ngrc_fastslow`, `rmse@50 = 0.0981`.
- Runner-up: `rc_raw`, `rmse@50 = 3.9750`.
- `rc_fastslow_readout` is also poor here: `5.0215`.
- Both NGRC variants are much worse: around `10.2` to `10.4`.

Interpretation:

- This task mixes chaos, partial observation, and process/observation noise.
- RC alone is not enough: the recurrent state smooths history but does not fully reconstruct the latent context.
- NGRC alone is also not enough: delay-coordinate polynomial features are too sensitive to noisy autoregressive accumulation.
- The hybrid wins because it combines two memory types: reservoir memory for noise-robust latent summarization, and delay memory for explicit short history.

Why this is credible:

- The gap is massive: `0.0981` versus the next best `3.9750`.
- The winner also has a much smaller mismatch ratio (`2.9`) than the RC and NGRC baselines.

Confidence:

- High confidence that hybrid memory is particularly valuable on noisy chaotic partial-observation tasks.

### `rossler_clean`

- Best model by `rmse@50`: `ngrc_fastslow_readout`, `0.00827`.
- Very close runner-up: `ngrc_raw`, `0.00858`.
- `rc_fastslow_readout` is worse at `rmse@50` (`0.0396`) but much better at `rmse@100` (`0.1130` vs `1.1991`).

Interpretation:

- On this cleaner and more regular chaotic attractor, short-horizon prediction is dominated by local delay-coordinate reconstruction, which suits NGRC extremely well.
- However, the NGRC advantage is mostly a short-to-mid horizon advantage. At longer rollout, RC is more stable.
- So the right statement is not "NGRC is better than RC" in general, but "NGRC is better on this task for the chosen main metric `rmse@50`."

Why this matters:

- The gap between the two NGRC variants is tiny, only about `3.8%`.
- The long-horizon reversal means this task should not be used to argue universal NGRC superiority.

Confidence:

- High confidence that delay-coordinate models are very strong on Rossler at `rmse@50`.
- Medium confidence on any stronger claim beyond that because `rmse@100` tells a different story.

## Low-Dimensional Multiscale / Forced Tasks

### `duffing_noisy`

- Best model: `ngrc_raw`, `rmse@50 = 0.0197`.
- Runner-up: `hybrid_rc_ngrc_fastslow`, `0.0311`.
- `ngrc_fastslow_readout` is much worse than `ngrc_raw`: `0.0440` vs `0.0197`.

Interpretation:

- Duffing here is low-dimensional and externally forced; the scalar signal already carries a strong locally reconstructable delay structure.
- Raw NGRC benefits from that simple local geometry.
- Adding fast/slow readout features actually hurts, likely because the extra coarse summaries are unnecessary and slightly distort the clean delay-based regression.

Why this is credible:

- The raw-to-fastslow degradation within the same NGRC family is substantial.
- The mismatch ratio is also better for `ngrc_raw` (`1.6`) than for `ngrc_fastslow_readout` (`3.6`).

Confidence:

- High confidence that NGRC is the strongest simple baseline for this forced low-dimensional task.
- High confidence that fast/slow augmentation is not universally helpful for NGRC.

### `fitzhugh_nagumo_noisy`

- Best model: `rc_raw`, `rmse@50 = 0.0138`.
- Runner-up: `rc_fastslow_readout`, `0.0162`.
- Hybrid is also close: `0.0170`.
- Structured residual models are much worse, all above `0.39`.

Interpretation:

- This is multiscale, but it is also low-dimensional and comparatively regular.
- The recurrent reservoir already captures enough phase information from the scalar trajectory.
- Fast/slow features help a little in one-step terms but do not improve the final `rmse@50`.
- The structured residual models likely over-constrain the problem: once the task is already easy for RC, adding a slow-backbone plus residual closure only increases failure modes.

Why this is credible:

- `rc_raw`, `rc_fastslow_readout`, and hybrid are all clustered tightly, so the safe conclusion is not "raw is fundamentally better," but "simple RC is already sufficient."

Confidence:

- High confidence that this task does not need the heavier structured machinery.
- Medium confidence that `rc_raw` is truly better than `rc_fastslow_readout`, because the gap is small.

### `vanderpol_stiff`

- Best model: `rc_fastslow_readout`, `rmse@50 = 0.000078`.
- Runner-up: `hybrid_rc_ngrc_fastslow`, `0.000085`.
- `rc_raw` is clearly worse: `0.000293`.
- Both NGRC variants fail badly: `3.02` and `3.80`.

Interpretation:

- This is exactly the regime where explicit multi-timescale summaries help: stiff dynamics with scalar partial observation.
- RC provides stable recurrent memory, and fast/slow features expose the slow envelope to the readout.
- NGRC is the wrong inductive bias here: delay-coordinate polynomial fitting can match one-step behavior, but rollout becomes catastrophically unstable on stiff oscillatory dynamics.

Why this is credible:

- The RC fast/slow gain over raw RC is about `3.75x`.
- The gap to NGRC is several orders of magnitude on the main metric.

Confidence:

- High confidence that RC-style recurrent memory is preferable to NGRC on stiff scalar multiscale systems.
- High confidence that fast/slow readout is genuinely useful in this regime.

### `vanderpol_shorttrain`

- Best model: `rc_raw`, `rmse@50 = 0.0188`.
- Runner-up: `rc_fastslow_readout`, `0.0210`.
- Hybrid is poor: `2.72`.
- Both NGRC variants collapse: around `9.4` to `9.6`.

Interpretation:

- The key stressor here is not only multiscale structure but limited training data.
- In short-data regimes, simpler models with fewer effective fitted degrees of freedom generalize better.
- RC still works because the reservoir itself is fixed and only a small linear readout is learned.
- NGRC and hybrid rely more directly on learned delay-polynomial relationships and become brittle under limited data.

Why this is credible:

- The winner and runner-up are both RC variants, and everything more complicated is significantly worse.
- This is one of the clearest examples where "more structure" or "more features" does not help.

Confidence:

- High confidence that short-train settings favor simpler RC baselines over NGRC and hybrid models.
- Medium confidence on the tiny `rc_raw` versus `rc_fastslow_readout` difference.

## High-Dimensional Chaotic Tasks

### `lorenz96_k16_partial`

- Best model: `hybrid_rc_ngrc_fastslow`, `rmse@50 = 1.1379`.
- Runner-up: `slow_sindy_only`, `1.5964`.
- `rc_fastslow_readout` is worse: `2.8926`.
- Raw baselines are much worse: `rc_raw = 6.8393`, `ngrc_raw = 5.3398`.

Interpretation:

- At moderate high dimension under scalar partial observation, neither pure reservoir memory nor pure delay memory is enough.
- The hybrid wins because it combines latent recurrent state with explicit delay coordinates, which helps reconstruct more of the hidden Lorenz-96 context.
- The fact that `slow_sindy_only` comes second suggests that a coarse slow manifold prior is not useless here, but the current residual structured models still do not capitalize on it well.

Why this is credible:

- The gap from hybrid to the raw baselines is large.
- This is one of the few tasks where the hybrid advantage is both large and clean.

Confidence:

- High confidence that hybrid memory is useful for moderate-dimensional partial-observation chaos.
- Medium confidence on interpreting `slow_sindy_only` as evidence for the current structured program, because the stronger structured residual variants do not follow through.

### `lorenz96_k32_partial`

- Best model: `ngrc_fastslow_readout`, `rmse@50 = 0.8544`.
- Runner-up: `ngrc_raw`, `1.3452`.
- `hybrid_rc_ngrc_fastslow` is third: `1.8164`.
- `rc_fastslow_readout` reaches `4.8094` and explodes at `rmse@100`.

Interpretation:

- Once the system dimension increases but the dynamics remain clean and deterministic, the dominant challenge becomes reconstructing the local observable geometry from scalar history.
- NGRC is well matched to that: delay coordinates plus polynomial features can exploit the clean deterministic structure efficiently.
- Fast/slow augmentation gives a moderate extra gain here, likely by supplying coarse trend context missing from pure delay terms.
- RC is weaker because the fixed reservoir does not recover the hidden high-dimensional state as effectively from the single observed coordinate.

Why this is credible:

- Both top models are NGRC-family models.
- The RC family is not merely slightly worse; its long rollout is much less reliable.

Confidence:

- High confidence that NGRC-style delay modeling is currently the best choice on clean high-dimensional Lorenz-96 partial observation.
- Medium confidence that fast/slow features are essential here, because `ngrc_raw` remains close.

### `lorenz96_k32_partial_noisy`

- Best model: `ngrc_fastslow_readout`, `rmse@50 = 1.7129`.
- Runner-up: `ngrc_raw`, `1.8634`.
- Third: `slow_sindy_delta_rc`, `2.3618`.
- `rc_fastslow_readout` is very poor: `7.3699`.

Interpretation:

- This is a noisy version of the previous task, and the picture changes less than expected: NGRC still wins.
- However, the gain from fast/slow augmentation is now small, only about `8.8%` over `ngrc_raw`.
- That means the strong claim is not "fast/slow solves noisy high-dimensional chaos." The stronger claim is "delay-based models remain competitive, and fast/slow adds at most a modest benefit here."
- The strong failure of `rc_fastslow_readout` is especially important: multi-timescale summaries do not rescue RC when the main difficulty is noisy high-dimensional chaotic state reconstruction.

Confidence:

- High confidence that NGRC is the best current family on this task.
- High confidence that the fast/slow gain here is modest rather than transformative.

## High-Dimensional Multiscale Tasks

### `lorenz96_twoscale_k12_j6`

- Best model by `rmse@50`: `rc_raw`, `0.0694`.
- Runner-up: `rc_fastslow_readout`, `0.1176`.
- But at `rmse@100`, `rc_fastslow_readout` is much better: `0.1478` vs `1.8356`.

Interpretation:

- This is a very important counterexample to simple one-line conclusions.
- The observation is already `slow0`, not a generic scalar projection. That means the measured variable is already aligned with the slow manifold.
- In that setting, explicit fast/slow features can be partly redundant for short-to-mid horizon accuracy, which is why `rc_raw` wins at `rmse@50`.
- But those same features improve stability over longer rollout, which is why `rmse@100` flips strongly in favor of `rc_fastslow_readout`.

What we can and cannot claim:

- We can claim that on directly observed slow variables, raw RC can be best at the main mid-horizon metric.
- We cannot claim that fast/slow readout is useless here, because it materially improves long-horizon stability.

Confidence:

- High confidence in the metric-dependent conclusion above.
- Low confidence in any blanket statement that either `rc_raw` or `rc_fastslow_readout` is categorically superior on this task without first fixing the evaluation horizon.

### `lorenz96_twoscale_k16_j4_noisy`

- Best model: `ngrc_raw`, `rmse@50 = 0.2920`.
- Runner-up: `slow_sindy_delta_rc`, `0.4136`.
- `rc_fastslow_readout` is close behind at `0.5247`.
- Hybrid is poor: `2.3456`.

Interpretation:

- This is the strongest challenge to the original structured narrative.
- The observation is again a slow variable (`slow0`), and the task is noisy.
- Raw NGRC works best because the slow observable plus delay coordinates already reconstruct enough effective state, without needing extra learned recurrent structure.
- The structured `slow_sindy_delta_rc` being second is still meaningful: explicit slow-backbone modeling is competitive under noisy multiscale high dimension, but the current implementation is not yet the best model.
- The hybrid failure suggests that combining many memory channels can become counterproductive when the observed variable already supplies a good slow coordinate and noise is present.

Confidence:

- High confidence that `ngrc_raw` is the strongest baseline on this task in the current table.
- Medium confidence that structured residual modeling is promising here, because it is competitive but not dominant.

## Confidence-Graded Conclusions

### High confidence

- There is no universal winner. After adding `rc_raw` and `ngrc_raw`, the wins spread across five model variants.
- Fast/slow readout is regime-dependent, not universal.
- NGRC is strongest when delay-coordinate reconstruction from the scalar observation is already informative and the task is not dominated by stiffness or short-data effects.
- RC-style recurrent memory is strongest on stiff or data-limited multiscale tasks.
- Hybrid RC+NGRC memory is especially valuable on noisy chaotic partial-observation tasks such as `lorenz63_noisy` and on moderate-dimensional partial-observation chaos such as `lorenz96_k16_partial`.

### Medium confidence

- On tasks where the observed signal is already a slow variable (`slow0`), explicit fast/slow features often become less important for `rmse@50`, though they can still help long-horizon stability.
- The current structured residual family captures some useful inductive bias on noisy high-dimensional multiscale tasks, but the implementation is not yet strong enough to beat simpler baselines consistently.

### Low confidence

- Any claim that `slow_sindy_delta_hybrid` is already a better practical model than the simpler baselines.
- Any claim based on training time fairness, because `train_time_sec` includes model selection over different-sized hyperparameter grids.
- Any claim of statistical superiority, because the current main table is still single-seed.

## Reviewer-Style Bottom Line

With the raw baselines restored, the strongest paper-safe conclusion is:

- Different memory mechanisms win in different dynamical regimes.
- Fast/slow features help when the task truly requires latent coarse-state reconstruction, but they are not universally beneficial.
- The current structured SINDy-residual direction is interesting but not yet empirically dominant.

The paper should therefore emphasize mechanism-level insights and regime matching, not universal model superiority.
