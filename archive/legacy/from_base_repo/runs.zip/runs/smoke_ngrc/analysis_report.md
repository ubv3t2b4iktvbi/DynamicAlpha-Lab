# Result analysis

## Best model by task

### lorenz63_smoke
- best one_step_rmse: `sindy_full` = 0.145631
- best rmse@10: `ngrc_fastslow_readout` = 0.0385938
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 2.4135
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 3.36032
- best acf_rmse: `rc_fastslow_readout` = 0.12393
- best psd_rmse: `sindy_full` = 0.0916795

### vanderpol_smoke
- best one_step_rmse: `rc_fastslow_readout` = 1.88924e-05
- best rmse@10: `rc_fastslow_readout` = 0.000194982
- best rmse@50: `rc_fastslow_readout` = 0.000558315
- best rmse@100: `rc_fastslow_readout` = 0.000594083
- best acf_rmse: `rc_fastslow_readout` = 0.000399739
- best psd_rmse: `rc_fastslow_readout` = 0.000142073

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| hybrid_rc_ngrc_fastslow |       0.880739  | 0.42457   |   1.2694  |    4.39805 |  0.333605  |  0.0591389 |             133 |              133 |           4357 |         2.04173  |             760.848 |
| rc_fastslow_readout     |       0.0956048 | 0.407811  |   2.59693 |    3.94856 |  0.0621648 |  0.0486642 |             120 |              124 |          14764 |         0.571511 |             163.435 |
| rc_raw                  |       0.245416  | 0.791884  |   3.88533 |    5.45865 |  0.0928725 |  0.0479577 |             120 |              122 |          14762 |         0.44875  |             137.474 |
| ngrc_raw                |       0.999918  | 0.0710366 |  13.2831  |   15.8823  |  0.752444  |  0.106764  |              93 |               93 |             93 |         0.140214 |             835.805 |
| ngrc_fastslow_readout   |       0.97913   | 0.0318877 |  13.7641  |   14.0271  |  0.728718  |  0.0960498 |              96 |               96 |             96 |         0.201102 |             686.695 |
| sindy_full              |       0.0728933 | 0.807796  |  24.1017  |   34.8608  |  0.144084  |  0.0565143 |              36 |               36 |             36 |         0.158728 |             349.963 |

## Parameter-aware notes

### rc_fastslow_readout vs rc_raw at the selected budgets
| task            |   raw_dim |   fs_dim |   raw_rmse50 |   fs_rmse50 |   gain50_pct |
|:----------------|----------:|---------:|-------------:|------------:|-------------:|
| lorenz63_smoke  |       120 |      120 |  7.76983     | 5.19329     |      33.1608 |
| vanderpol_smoke |       120 |      120 |  0.000834153 | 0.000558315 |      33.068  |

## Instability flags

| task            | variant                 |     rmse@10 |   rmse@50 |   rmse@100 |   effective_dim |   trained_params |
|:----------------|:------------------------|------------:|----------:|-----------:|----------------:|-----------------:|
| lorenz63_smoke  | ngrc_raw                | 0.117323    | 15.3569   |   19.5573  |              66 |               66 |
| lorenz63_smoke  | ngrc_fastslow_readout   | 0.0385938   | 15.975    |   18.2632  |              69 |               69 |
| lorenz63_smoke  | sindy_full              | 1.55425     | 29.5588   |   38.1169  |              36 |               36 |
| vanderpol_smoke | ngrc_raw                | 0.0247507   | 11.2093   |   12.2073  |             120 |              120 |
| vanderpol_smoke | ngrc_fastslow_readout   | 0.0251817   | 11.5531   |    9.79097 |             123 |              123 |
| vanderpol_smoke | hybrid_rc_ngrc_fastslow | 0.000279273 |  0.125298 |    5.43578 |             133 |              133 |
| vanderpol_smoke | sindy_full              | 0.0613421   | 18.6445   |   31.6046  |              36 |               36 |

## One-step vs long-horizon mismatch

| task            | variant                 |   one_step_rmse |      rmse@50 |   mismatch_ratio |   effective_dim |
|:----------------|:------------------------|----------------:|-------------:|-----------------:|----------------:|
| vanderpol_smoke | ngrc_fastslow_readout   |     4.03702e-05 | 11.5531      |     286179       |             123 |
| vanderpol_smoke | ngrc_raw                |     3.98504e-05 | 11.2093      |     281286       |             120 |
| vanderpol_smoke | sindy_full              |     0.000155732 | 18.6445      |     119722       |              36 |
| vanderpol_smoke | hybrid_rc_ngrc_fastslow |     4.22476e-05 |  0.125298    |       2965.8     |             133 |
| lorenz63_smoke  | sindy_full              |     0.145631    | 29.5588      |        202.971   |              36 |
| vanderpol_smoke | rc_raw                  |     2.04013e-05 |  0.000834153 |         40.8872  |             120 |
| vanderpol_smoke | rc_fastslow_readout     |     1.88924e-05 |  0.000558315 |         29.5523  |             120 |
| lorenz63_smoke  | rc_fastslow_readout     |     0.191191    |  5.19329     |         27.1629  |             120 |
| lorenz63_smoke  | rc_raw                  |     0.490812    |  7.76983     |         15.8306  |             120 |
| lorenz63_smoke  | ngrc_fastslow_readout   |     1.95822     | 15.975       |          8.15794 |              69 |
| lorenz63_smoke  | ngrc_raw                |     1.9998      | 15.3569      |          7.67924 |              66 |
| lorenz63_smoke  | hybrid_rc_ngrc_fastslow |     1.76144     |  2.4135      |          1.37019 |             133 |
