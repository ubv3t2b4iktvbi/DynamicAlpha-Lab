# Result analysis

## Best model by task

### fitzhugh_nagumo_noisy
- best one_step_rmse: `rc_fastslow_readout` = 0.0124606
- best rmse@10: `rc_fastslow_readout` = 0.0129047
- best rmse@50: `rc_fastslow_readout` = 0.0162231
- best rmse@100: `rc_fastslow_readout` = 0.0170996
- best acf_rmse: `ngrc_fastslow_readout` = 0.0018339
- best psd_rmse: `rc_fastslow_readout` = 0.00229901
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`noisy_partial`

### vanderpol_shorttrain
- best one_step_rmse: `slow_sindy_delta_ngrc` = 0.0452955
- best rmse@10: `rc_fastslow_readout` = 0.00997803
- best rmse@50: `rc_fastslow_readout` = 0.0209867
- best rmse@100: `rc_fastslow_readout` = 0.0282281
- best acf_rmse: `rc_fastslow_readout` = 0.00537603
- best psd_rmse: `rc_fastslow_readout` = 0.000486391
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`short_train`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| rc_fastslow_readout     |       0.048776  | 0.0114413 | 0.0186049 |  0.0226638 |  0.0071721 | 0.0013927  |           180   |            184   |        36544   |        5.0325    |             325.878 |
| slow_sindy_delta_hybrid |       0.041951  | 0.054986  | 0.399936  |  0.576153  |  0.0424444 | 0.0151656  |           195   |            195   |         9627   |       55.6614    |            1871.18  |
| slow_sindy_delta_ngrc   |       0.0300949 | 0.0607813 | 0.558768  |  1.79327   |  0.0262419 | 0.013739   |            92.5 |             92.5 |           92.5 |       23.338     |            1519.21  |
| slow_sindy_delta_rc     |       0.0533513 | 0.133775  | 0.56673   |  0.667427  |  0.115481  | 0.0152018  |           246   |            252   |        58332   |       35.2396    |             592.792 |
| slow_sindy_only         |       0.194034  | 0.430311  | 0.588536  |  0.689874  |  0.104249  | 0.009121   |             6   |              6   |            6   |        0.0479341 |             337.537 |
| hybrid_rc_ngrc_fastslow |       0.0367274 | 0.539927  | 1.36929   |  1.48703   |  0.154862  | 0.00994257 |           188   |            188   |         9620   |       11.5065    |            1627.5   |
| ngrc_fastslow_readout   |       0.0720228 | 3.44308   | 4.8353    |  5.08598   |  0.279676  | 0.0198081  |           178.5 |            178.5 |          178.5 |        1.35625   |            2333.31  |

## Family-wise averages

|                                                  |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |
|:-------------------------------------------------|----------:|----------:|-----------:|-----------:|-----------:|
| ('lowdim_multiscale', 'rc_fastslow_readout')     | 0.0114413 | 0.0186049 |  0.0226638 |  0.0071721 | 0.0013927  |
| ('lowdim_multiscale', 'slow_sindy_delta_hybrid') | 0.054986  | 0.399936  |  0.576153  |  0.0424444 | 0.0151656  |
| ('lowdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.0607813 | 0.558768  |  1.79327   |  0.0262419 | 0.013739   |
| ('lowdim_multiscale', 'slow_sindy_delta_rc')     | 0.133775  | 0.56673   |  0.667427  |  0.115481  | 0.0152018  |
| ('lowdim_multiscale', 'slow_sindy_only')         | 0.430311  | 0.588536  |  0.689874  |  0.104249  | 0.009121   |
| ('lowdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.539927  | 1.36929   |  1.48703   |  0.154862  | 0.00994257 |
| ('lowdim_multiscale', 'ngrc_fastslow_readout')   | 3.44308   | 4.8353    |  5.08598   |  0.279676  | 0.0198081  |

## Dimension scaling

|   state_dim | variant                 |   rmse@50 |   rmse@100 |   one_step_rmse |
|------------:|:------------------------|----------:|-----------:|----------------:|
|           2 | rc_fastslow_readout     | 0.0186049 |  0.0226638 |       0.048776  |
|           2 | slow_sindy_delta_hybrid | 0.399936  |  0.576153  |       0.041951  |
|           2 | slow_sindy_delta_ngrc   | 0.558768  |  1.79327   |       0.0300949 |
|           2 | slow_sindy_delta_rc     | 0.56673   |  0.667427  |       0.0533513 |
|           2 | slow_sindy_only         | 0.588536  |  0.689874  |       0.194034  |
|           2 | hybrid_rc_ngrc_fastslow | 1.36929   |  1.48703   |       0.0367274 |
|           2 | ngrc_fastslow_readout   | 4.8353    |  5.08598   |       0.0720228 |

### Best variant per state dimension
|   state_dim | best_variant        |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:--------------------|-------------:|-------------:|--------------:|
|           2 | rc_fastslow_readout |            2 |    0.0186049 |     0.0226638 |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |       2 |          0.969356 |            0.91088 |                  4.38374 | A slow-manifold prior should help on multiscale high-dimensional tasks. |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |       2 |          0.158832 |            1.21712 |                  8.3066  | Adding reservoir memory should stabilize residual NGRC rollouts.        |
| dual_memory_vs_single_memory     | rc_fastslow_readout     | hybrid_rc_ngrc_fastslow |       2 |         -1.35069  |           -1.46437 |                -22.2391  | Combining recurrent and delay memories should improve horizon balance.  |

## One-step vs long-horizon mismatch

| task                  | variant                 |   one_step_rmse |   rmse@50 |   mismatch_ratio |   state_dim |
|:----------------------|:------------------------|----------------:|----------:|-----------------:|------------:|
| vanderpol_shorttrain  | ngrc_fastslow_readout   |       0.129956  | 9.64332   |        74.2045   |           2 |
| vanderpol_shorttrain  | hybrid_rc_ngrc_fastslow |       0.0609233 | 2.72162   |        44.6729   |           2 |
| fitzhugh_nagumo_noisy | slow_sindy_delta_ngrc   |       0.0148942 | 0.647992  |        43.5063   |           2 |
| fitzhugh_nagumo_noisy | slow_sindy_delta_hybrid |       0.01397   | 0.450776  |        32.2674   |           2 |
| fitzhugh_nagumo_noisy | slow_sindy_delta_rc     |       0.018193  | 0.398697  |        21.9148   |           2 |
| vanderpol_shorttrain  | slow_sindy_delta_ngrc   |       0.0452955 | 0.469544  |        10.3662   |           2 |
| vanderpol_shorttrain  | slow_sindy_delta_rc     |       0.0885095 | 0.734763  |         8.30151  |           2 |
| vanderpol_shorttrain  | slow_sindy_only         |       0.151165  | 0.836092  |         5.53101  |           2 |
| vanderpol_shorttrain  | slow_sindy_delta_hybrid |       0.069932  | 0.349096  |         4.99193  |           2 |
| fitzhugh_nagumo_noisy | ngrc_fastslow_readout   |       0.0140896 | 0.0272772 |         1.93598  |           2 |
| fitzhugh_nagumo_noisy | slow_sindy_only         |       0.236903  | 0.340979  |         1.43932  |           2 |
| fitzhugh_nagumo_noisy | hybrid_rc_ngrc_fastslow |       0.0125315 | 0.0169664 |         1.35391  |           2 |
| fitzhugh_nagumo_noisy | rc_fastslow_readout     |       0.0124606 | 0.0162231 |         1.30195  |           2 |
| vanderpol_shorttrain  | rc_fastslow_readout     |       0.0850915 | 0.0209867 |         0.246637 |           2 |

## Insights

- Injecting a slow SINDy backbone helps when the task family is genuinely multiscale or high-dimensional, which matches the idea that an explicit resolved slow manifold stabilizes forecasting.
- The new slow-SINDy delta hybrid reduces residual-model mismatch relative to pure NGRC closure, suggesting that residual dynamics also benefit from recurrent state regularization.

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `rc_fastslow_readout` is only the most frequent winner, not a universal winner.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
