# Result analysis

## Best model by task

### duffing_noisy
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.012167
- best rmse@10: `slow_sindy_delta_rc` = 0.0110133
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 0.0310664
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.0444808
- best acf_rmse: `slow_sindy_delta_hybrid` = 0.10166
- best psd_rmse: `rc_fastslow_readout` = 0.0801586
- metadata: state_dim=2, family=`forced_nonlinear`, regime=`noisy_partial`

### lorenz63_clean
- best one_step_rmse: `rc_fastslow_readout` = 0.00257142
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.00490573
- best rmse@50: `rc_fastslow_readout` = 0.237198
- best rmse@100: `rc_fastslow_readout` = 1.43599
- best acf_rmse: `rc_fastslow_readout` = 0.0408177
- best psd_rmse: `rc_fastslow_readout` = 0.0192662
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`clean_partial`

### lorenz63_noisy
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.0341881
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.0344762
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 0.0981226
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.411773
- best acf_rmse: `hybrid_rc_ngrc_fastslow` = 0.0271677
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 0.00262241
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`noisy_partial`

### rossler_clean
- best one_step_rmse: `ngrc_fastslow_readout` = 5.22428e-05
- best rmse@10: `ngrc_fastslow_readout` = 0.000224683
- best rmse@50: `ngrc_fastslow_readout` = 0.00827122
- best rmse@100: `rc_fastslow_readout` = 0.113024
- best acf_rmse: `slow_sindy_delta_ngrc` = 0.0153803
- best psd_rmse: `slow_sindy_delta_ngrc` = 0.0019759
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`clean_partial`

### vanderpol_stiff
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 9.42088e-06
- best rmse@10: `rc_fastslow_readout` = 1.02977e-05
- best rmse@50: `rc_fastslow_readout` = 7.77382e-05
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.000106238
- best acf_rmse: `hybrid_rc_ngrc_fastslow` = 9.76343e-05
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 3.25049e-05
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`stiff_partial`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |   rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-----------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| hybrid_rc_ngrc_fastslow |      0.00994387 | 0.0110898 |  0.578183 |    2.88431 |   0.398851 |  0.0475908 |           243   |            243   |        14883   |       15.295     |            2240.03  |
| rc_fastslow_readout     |      0.0218074  | 0.0742049 |  1.06833  |    1.3998  |   0.117013 |  0.0332227 |           216   |            220   |        49612   |        4.61742   |             346.758 |
| slow_sindy_only         |      2.18174    | 2.86903   |  3.47673  |    3.51673 |   0.17019  |  0.0406319 |             6   |              6   |            6   |        0.0385024 |             355.148 |
| ngrc_fastslow_readout   |      0.0133648  | 0.183828  |  3.51961  |    6.94413 |   0.637986 |  0.073895  |           167.4 |            167.4 |          167.4 |        1.85382   |            2166.38  |
| slow_sindy_delta_hybrid |      0.0512479  | 1.65264   |  3.94163  |    6.69537 |   0.169275 |  0.0368641 |           184   |            184   |         8574.4 |       80.7646    |            2209.15  |
| slow_sindy_delta_ngrc   |      0.0718961  | 2.21834   |  4.33744  |    4.7244  |   0.270131 |  0.0470663 |           108.4 |            108.4 |          108.4 |       34.2199    |            1476.32  |
| slow_sindy_delta_rc     |      0.0532235  | 1.58098   |  7.40645  |    8.14792 |   0.214244 |  0.0523551 |           150   |            156   |        23484   |       42.036     |             544.79  |

## Family-wise averages

|                                                  |     rmse@10 |      rmse@50 |     rmse@100 |    acf_rmse |    psd_rmse |
|:-------------------------------------------------|------------:|-------------:|-------------:|------------:|------------:|
| ('lowdim_multiscale', 'rc_fastslow_readout')     | 1.02977e-05 |  7.77382e-05 |  0.000184728 | 0.000154375 | 4.04884e-05 |
| ('lowdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 2.68185e-05 |  8.48961e-05 |  0.000106238 | 9.76343e-05 | 3.25049e-05 |
| ('lowdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.00257241  |  0.0125372   |  0.089559    | 0.565067    | 0.0376161   |
| ('lowdim_multiscale', 'slow_sindy_delta_rc')     | 0.00276024  |  0.016216    |  0.0323579   | 0.0562338   | 0.00802257  |
| ('lowdim_multiscale', 'slow_sindy_delta_hybrid') | 0.00306613  |  0.0192209   |  0.0394691   | 0.106887    | 0.012177    |
| ('lowdim_multiscale', 'slow_sindy_only')         | 0.00489717  |  0.0200382   |  0.0436534   | 0.13232     | 0.0141368   |
| ('forced_nonlinear', 'hybrid_rc_ngrc_fastslow')  | 0.0150634   |  0.0310664   |  0.0444808   | 0.203861    | 0.0861497   |
| ('forced_nonlinear', 'rc_fastslow_readout')      | 0.0255445   |  0.0432304   |  0.0549092   | 0.216768    | 0.0801586   |
| ('forced_nonlinear', 'ngrc_fastslow_readout')    | 0.0125008   |  0.0440489   |  0.0775803   | 0.269981    | 0.101466    |
| ('forced_nonlinear', 'slow_sindy_delta_hybrid')  | 0.0144055   |  0.106681    |  0.488627    | 0.10166     | 0.0835987   |
| ('forced_nonlinear', 'slow_sindy_only')          | 0.148265    |  0.159974    |  0.129592    | 0.215188    | 0.0907229   |
| ('forced_nonlinear', 'slow_sindy_delta_ngrc')    | 0.0132838   |  0.182141    |  0.923395    | 0.225224    | 0.0923004   |
| ('forced_nonlinear', 'slow_sindy_delta_rc')      | 0.0110133   |  0.187349    |  0.330912    | 0.150704    | 0.0948943   |
| ('lowdim_chaotic', 'hybrid_rc_ngrc_fastslow')    | 0.0134529   |  0.953255    |  4.79233     | 0.596765    | 0.0505905   |
| ('lowdim_chaotic', 'rc_fastslow_readout')        | 0.115157    |  1.76611     |  2.31464     | 0.122713    | 0.0286381   |
| ('lowdim_multiscale', 'ngrc_fastslow_readout')   | 0.0022598   |  3.80461     | 10.6003      | 1.02409     | 0.0777625   |
| ('lowdim_chaotic', 'ngrc_fastslow_readout')      | 0.30146     |  4.58313     |  8.01427     | 0.631954    | 0.0634155   |
| ('lowdim_chaotic', 'slow_sindy_only')            | 4.73066     |  5.73455     |  5.80348     | 0.167814    | 0.0327666   |
| ('lowdim_chaotic', 'slow_sindy_delta_hybrid')    | 2.74858     |  6.52742     | 10.9829      | 0.21261     | 0.029515    |
| ('lowdim_chaotic', 'slow_sindy_delta_ngrc')      | 3.69195     |  7.16417     |  7.53634     | 0.186788    | 0.0351382   |
| ('lowdim_chaotic', 'slow_sindy_delta_rc')        | 2.63038     | 12.2762      | 13.4588      | 0.288094    | 0.0529529   |

## Dimension scaling

|   state_dim | variant                 |    rmse@50 |   rmse@100 |   one_step_rmse |
|------------:|:------------------------|-----------:|-----------:|----------------:|
|           2 | hybrid_rc_ngrc_fastslow |  0.0155756 |  0.0222935 |      0.0060882  |
|           2 | rc_fastslow_readout     |  0.021654  |  0.027547  |      0.00913027 |
|           2 | slow_sindy_delta_hybrid |  0.0629508 |  0.264048  |      0.00909333 |
|           2 | slow_sindy_only         |  0.0900062 |  0.0866225 |      0.179292   |
|           2 | slow_sindy_delta_ngrc   |  0.097339  |  0.506477  |      0.00748396 |
|           2 | slow_sindy_delta_rc     |  0.101783  |  0.181635  |      0.0079175  |
|           2 | ngrc_fastslow_readout   |  1.92433   |  5.33892   |      0.00632847 |
|           3 | hybrid_rc_ngrc_fastslow |  0.953255  |  4.79233   |      0.0125143  |
|           3 | rc_fastslow_readout     |  1.76611   |  2.31464   |      0.0302588  |
|           3 | ngrc_fastslow_readout   |  4.58313   |  8.01427   |      0.0180558  |
|           3 | slow_sindy_only         |  5.73455   |  5.80348   |      3.5167     |
|           3 | slow_sindy_delta_hybrid |  6.52742   | 10.9829    |      0.0793509  |
|           3 | slow_sindy_delta_ngrc   |  7.16417   |  7.53634   |      0.114837   |
|           3 | slow_sindy_delta_rc     | 12.2762    | 13.4588    |      0.0834276  |

### Best variant per state dimension
|   state_dim | best_variant          |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:----------------------|-------------:|-------------:|--------------:|
|           2 | rc_fastslow_readout   |            2 |     0.021654 |      0.027547 |
|           3 | ngrc_fastslow_readout |            3 |     4.58313  |      8.01427  |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| dual_memory_vs_single_memory     | rc_fastslow_readout     | hybrid_rc_ngrc_fastslow |       5 |          0.490146 |           -1.48451 |               -207.095   | Combining recurrent and delay memories should improve horizon balance.  |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |       5 |          0.395805 |           -1.97098 |                 -6.74037 | Adding reservoir memory should stabilize residual NGRC rollouts.        |
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |       5 |         -3.36345  |           -3.81106 |                195.952   | A slow-manifold prior should help on multiscale high-dimensional tasks. |

## One-step vs long-horizon mismatch

| task            | variant                 |   one_step_rmse |     rmse@50 |   mismatch_ratio |   state_dim |
|:----------------|:------------------------|----------------:|------------:|-----------------:|------------:|
| vanderpol_stiff | ngrc_fastslow_readout   |     0.000304778 |  3.80461    |       12483.2    |           2 |
| lorenz63_clean  | ngrc_fastslow_readout   |     0.00399075  |  3.51003    |         879.541  |           3 |
| lorenz63_clean  | hybrid_rc_ngrc_fastslow |     0.00323371  |  2.71315    |         839.019  |           3 |
| rossler_clean   | hybrid_rc_ngrc_fastslow |     0.000121134 |  0.0484974  |         400.361  |           3 |
| lorenz63_noisy  | slow_sindy_delta_rc     |     0.0923605   | 22.8767     |         247.689  |           3 |
| lorenz63_noisy  | ngrc_fastslow_readout   |     0.0501243   | 10.2311     |         204.115  |           3 |
| rossler_clean   | ngrc_fastslow_readout   |     5.22428e-05 |  0.00827122 |         158.323  |           3 |
| lorenz63_noisy  | slow_sindy_delta_ngrc   |     0.0796647   | 10.4109     |         130.683  |           3 |
| lorenz63_clean  | slow_sindy_delta_hybrid |     0.0667491   |  8.48747    |         127.155  |           3 |
| lorenz63_clean  | slow_sindy_delta_rc     |     0.0990375   | 10.5739     |         106.767  |           3 |
| lorenz63_clean  | rc_fastslow_readout     |     0.00257142  |  0.237198   |          92.2438 |           3 |
| lorenz63_noisy  | slow_sindy_delta_hybrid |     0.0732074   |  6.29725    |          86.0192 |           3 |
| rossler_clean   | rc_fastslow_readout     |     0.000673455 |  0.0396145  |          58.8228 |           3 |
| lorenz63_noisy  | rc_fastslow_readout     |     0.0875314   |  5.02153    |          57.3682 |           3 |
| rossler_clean   | slow_sindy_delta_rc     |     0.0588847   |  3.37809    |          57.3678 |           3 |
| rossler_clean   | slow_sindy_delta_ngrc   |     0.0980685   |  5.41429    |          55.2093 |           3 |
| rossler_clean   | slow_sindy_delta_hybrid |     0.0980962   |  4.79754    |          48.9065 |           3 |
| lorenz63_clean  | slow_sindy_delta_ngrc   |     0.166779    |  5.66736    |          33.9812 |           3 |
| duffing_noisy   | slow_sindy_delta_rc     |     0.0129578   |  0.187349   |          14.4584 |           2 |
| duffing_noisy   | slow_sindy_delta_ngrc   |     0.0130438   |  0.182141   |          13.9637 |           2 |

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `hybrid_rc_ngrc_fastslow` is only the most frequent winner, not a universal winner.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
