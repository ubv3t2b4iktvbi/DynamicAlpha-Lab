# Result analysis

## Best model by task

### duffing_noisy
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.012167
- best rmse@10: `slow_sindy_delta_rc` = 0.0110133
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 0.0310664
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.0444808
- best acf_rmse: `slow_sindy_delta_hybrid` = 0.10166
- best psd_rmse: `rc_fastslow_readout` = 0.0801586
- metadata: state_dim=2, family=`forced_nonlinear`, regime=`noisy_partial`

### fitzhugh_nagumo_noisy
- best one_step_rmse: `rc_fastslow_readout` = 0.0124606
- best rmse@10: `rc_fastslow_readout` = 0.0129047
- best rmse@50: `rc_fastslow_readout` = 0.0162231
- best rmse@100: `rc_fastslow_readout` = 0.0170996
- best acf_rmse: `ngrc_fastslow_readout` = 0.0018339
- best psd_rmse: `rc_fastslow_readout` = 0.00229901
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`noisy_partial`

### lorenz63_clean
- best one_step_rmse: `rc_fastslow_readout` = 0.00257142
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.00490573
- best rmse@50: `rc_fastslow_readout` = 0.237198
- best rmse@100: `rc_fastslow_readout` = 1.43599
- best acf_rmse: `rc_fastslow_readout` = 0.0408177
- best psd_rmse: `rc_fastslow_readout` = 0.0192662
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`clean_partial`

### lorenz63_noisy
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.0341881
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.0344762
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 0.0981226
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.411773
- best acf_rmse: `hybrid_rc_ngrc_fastslow` = 0.0271677
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 0.00262241
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`noisy_partial`

### lorenz96_k16_partial
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000946721
- best rmse@10: `hybrid_rc_ngrc_fastslow` = 0.0216341
- best rmse@50: `hybrid_rc_ngrc_fastslow` = 1.13792
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.858179
- best acf_rmse: `rc_fastslow_readout` = 0.0471755
- best psd_rmse: `rc_fastslow_readout` = 0.00965695
- metadata: state_dim=16, family=`highdim_chaotic`, regime=`dimension_scaling`

### lorenz96_k32_partial
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000531059
- best rmse@10: `ngrc_fastslow_readout` = 0.010395
- best rmse@50: `ngrc_fastslow_readout` = 0.854362
- best rmse@100: `ngrc_fastslow_readout` = 2.08106
- best acf_rmse: `slow_sindy_only` = 0.0136325
- best psd_rmse: `slow_sindy_only` = 0.0154424
- metadata: state_dim=32, family=`highdim_chaotic`, regime=`dimension_scaling`

### lorenz96_k32_partial_noisy
- best one_step_rmse: `ngrc_fastslow_readout` = 0.0347783
- best rmse@10: `rc_fastslow_readout` = 0.0385224
- best rmse@50: `ngrc_fastslow_readout` = 1.71293
- best rmse@100: `ngrc_fastslow_readout` = 4.18927
- best acf_rmse: `slow_sindy_only` = 0.137964
- best psd_rmse: `slow_sindy_only` = 0.0205726
- metadata: state_dim=32, family=`highdim_chaotic`, regime=`dimension_scaling_noisy`

### lorenz96_twoscale_k12_j6
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 0.000112048
- best rmse@10: `rc_fastslow_readout` = 0.00113637
- best rmse@50: `rc_fastslow_readout` = 0.117645
- best rmse@100: `rc_fastslow_readout` = 0.147832
- best acf_rmse: `slow_sindy_only` = 0.00912878
- best psd_rmse: `rc_fastslow_readout` = 0.0181788
- metadata: state_dim=84, family=`highdim_multiscale`, regime=`dimension_scaling`

### lorenz96_twoscale_k16_j4_noisy
- best one_step_rmse: `ngrc_fastslow_readout` = 0.0281151
- best rmse@10: `ngrc_fastslow_readout` = 0.0670569
- best rmse@50: `slow_sindy_delta_rc` = 0.413621
- best rmse@100: `rc_fastslow_readout` = 1.264
- best acf_rmse: `slow_sindy_delta_hybrid` = 0.00992637
- best psd_rmse: `rc_fastslow_readout` = 0.0110511
- metadata: state_dim=80, family=`highdim_multiscale`, regime=`dimension_scaling_noisy`

### rossler_clean
- best one_step_rmse: `ngrc_fastslow_readout` = 5.22428e-05
- best rmse@10: `ngrc_fastslow_readout` = 0.000224683
- best rmse@50: `ngrc_fastslow_readout` = 0.00827122
- best rmse@100: `rc_fastslow_readout` = 0.113024
- best acf_rmse: `slow_sindy_delta_ngrc` = 0.0153803
- best psd_rmse: `slow_sindy_delta_ngrc` = 0.0019759
- metadata: state_dim=3, family=`lowdim_chaotic`, regime=`clean_partial`

### vanderpol_shorttrain
- best one_step_rmse: `slow_sindy_delta_ngrc` = 0.0452955
- best rmse@10: `rc_fastslow_readout` = 0.00997803
- best rmse@50: `rc_fastslow_readout` = 0.0209867
- best rmse@100: `rc_fastslow_readout` = 0.0282281
- best acf_rmse: `rc_fastslow_readout` = 0.00537603
- best psd_rmse: `rc_fastslow_readout` = 0.000486391
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`short_train`

### vanderpol_stiff
- best one_step_rmse: `hybrid_rc_ngrc_fastslow` = 9.42088e-06
- best rmse@10: `rc_fastslow_readout` = 1.02977e-05
- best rmse@50: `rc_fastslow_readout` = 7.77382e-05
- best rmse@100: `hybrid_rc_ngrc_fastslow` = 0.000106238
- best acf_rmse: `hybrid_rc_ngrc_fastslow` = 9.76343e-05
- best psd_rmse: `hybrid_rc_ngrc_fastslow` = 3.25049e-05
- metadata: state_dim=2, family=`lowdim_multiscale`, regime=`stiff_partial`

## Cross-task averages

| variant                 |   one_step_rmse |   rmse@10 |   rmse@50 |     rmse@100 |   acf_rmse |   psd_rmse |   effective_dim |   trained_params |   total_params |   train_time_sec |   speed_us_per_step |
|:------------------------|----------------:|----------:|----------:|-------------:|-----------:|-----------:|----------------:|-----------------:|---------------:|-----------------:|--------------------:|
| hybrid_rc_ngrc_fastslow |       0.0157825 |  0.132774 |   1.2199  |      2.92981 |   0.279985 |  0.0352728 |         197.167 |          197.167 |       10497.2  |       17.8793    |            2238.81  |
| rc_fastslow_readout     |       0.0249307 |  0.11551  |   1.75775 | 691841       |   0.184335 |  0.0276623 |         190     |          194     |       40174    |        5.00624   |             420.016 |
| slow_sindy_only         |       1.61927   |  1.64756  |   2.25138 |      2.70684 |   0.129988 |  0.0305659 |           6     |            6     |           6    |        0.0453447 |             400.118 |
| slow_sindy_delta_hybrid |       0.0468343 |  0.915722 |   2.81874 |      4.58757 |   0.146362 |  0.0390455 |         204.167 |          204.167 |       10504.2  |       98.0387    |            2852.56  |
| ngrc_fastslow_readout   |       0.0233583 |  0.6751   |   2.96929 |      5.73452 |   0.41376  |  0.05125   |         169.25  |          169.25  |         169.25 |        1.72992   |            2707.83  |
| slow_sindy_delta_ngrc   |       0.0533988 |  1.15612  |   3.00241 |      4.1886  |   0.182268 |  0.0436637 |         101.25  |          101.25  |         101.25 |       41.5018    |            2240.35  |
| slow_sindy_delta_rc     |       0.0528848 |  0.888308 |   4.02972 |      5.58087 |   0.223061 |  0.0468565 |         186     |          192     |       36552    |       48.4219    |             820.934 |

## Family-wise averages

|                                                   |    rmse@10 |    rmse@50 |     rmse@100 |   acf_rmse |    psd_rmse |
|:--------------------------------------------------|-----------:|-----------:|-------------:|-----------:|------------:|
| ('lowdim_multiscale', 'rc_fastslow_readout')      | 0.00763099 |  0.0124292 |  0.0151708   | 0.00483286 | 0.000941962 |
| ('forced_nonlinear', 'hybrid_rc_ngrc_fastslow')   | 0.0150634  |  0.0310664 |  0.0444808   | 0.203861   | 0.0861497   |
| ('forced_nonlinear', 'rc_fastslow_readout')       | 0.0255445  |  0.0432304 |  0.0549092   | 0.216768   | 0.0801586   |
| ('forced_nonlinear', 'ngrc_fastslow_readout')     | 0.0125008  |  0.0440489 |  0.0775803   | 0.269981   | 0.101466    |
| ('forced_nonlinear', 'slow_sindy_delta_hybrid')   | 0.0144055  |  0.106681  |  0.488627    | 0.10166    | 0.0835987   |
| ('forced_nonlinear', 'slow_sindy_only')           | 0.148265   |  0.159974  |  0.129592    | 0.215188   | 0.0907229   |
| ('forced_nonlinear', 'slow_sindy_delta_ngrc')     | 0.0132838  |  0.182141  |  0.923395    | 0.225224   | 0.0923004   |
| ('forced_nonlinear', 'slow_sindy_delta_rc')       | 0.0110133  |  0.187349  |  0.330912    | 0.150704   | 0.0948943   |
| ('lowdim_multiscale', 'slow_sindy_delta_hybrid')  | 0.0376794  |  0.273031  |  0.397259    | 0.0639252  | 0.0141694   |
| ('highdim_multiscale', 'rc_fastslow_readout')     | 0.0500597  |  0.321153  |  0.705914    | 0.0201885  | 0.0146149   |
| ('lowdim_multiscale', 'slow_sindy_delta_ngrc')    | 0.0413783  |  0.376691  |  1.22537     | 0.20585    | 0.021698    |
| ('lowdim_multiscale', 'slow_sindy_delta_rc')      | 0.0901032  |  0.383225  |  0.455738    | 0.0957316  | 0.0128087   |
| ('lowdim_multiscale', 'slow_sindy_only')          | 0.288506   |  0.399037  |  0.474467    | 0.113606   | 0.0107929   |
| ('highdim_multiscale', 'ngrc_fastslow_readout')   | 0.0347535  |  0.607559  |  1.95853     | 0.0354242  | 0.0237392   |
| ('highdim_multiscale', 'slow_sindy_delta_rc')     | 0.0731823  |  0.86204   |  4.01769     | 0.0613108  | 0.0472393   |
| ('highdim_multiscale', 'slow_sindy_only')         | 0.920339   |  0.868607  |  2.04177     | 0.0467765  | 0.0421041   |
| ('lowdim_multiscale', 'hybrid_rc_ngrc_fastslow')  | 0.35996    |  0.91289   |  0.991391    | 0.103274   | 0.00663922  |
| ('lowdim_chaotic', 'hybrid_rc_ngrc_fastslow')     | 0.0134529  |  0.953255  |  4.79233     | 0.596765   | 0.0505905   |
| ('highdim_multiscale', 'slow_sindy_delta_ngrc')   | 0.0671419  |  0.960476  |  2.71032     | 0.0805591  | 0.0305164   |
| ('highdim_multiscale', 'slow_sindy_delta_hybrid') | 0.0686819  |  0.995865  |  3.69361     | 0.013575   | 0.0455752   |
| ('highdim_multiscale', 'hybrid_rc_ngrc_fastslow') | 0.0758038  |  1.24587   |  2.15648     | 0.0321433  | 0.0354055   |
| ('lowdim_chaotic', 'rc_fastslow_readout')         | 0.115157   |  1.76611   |  2.31464     | 0.122713   | 0.0286381   |
| ('highdim_chaotic', 'hybrid_rc_ngrc_fastslow')    | 0.102127   |  2.17253   |  4.48303     | 0.33052    | 0.0315413   |
| ('highdim_chaotic', 'slow_sindy_only')            | 0.908084   |  2.23954   |  3.14502     | 0.135617   | 0.0203937   |
| ('highdim_chaotic', 'ngrc_fastslow_readout')      | 0.0754667  |  2.38258   |  6.6682      | 0.381662   | 0.0528101   |
| ('highdim_chaotic', 'slow_sindy_delta_rc')        | 0.780291   |  2.82227   |  5.62022     | 0.417309   | 0.0585402   |
| ('highdim_chaotic', 'slow_sindy_delta_ngrc')      | 0.841973   |  3.76775   |  5.87799     | 0.207655   | 0.0667076   |
| ('highdim_chaotic', 'slow_sindy_delta_hybrid')    | 0.826039   |  3.77505   |  4.34481     | 0.265976   | 0.054248    |
| ('lowdim_multiscale', 'ngrc_fastslow_readout')    | 2.29614    |  4.49173   |  6.92407     | 0.527813   | 0.0391262   |
| ('lowdim_chaotic', 'ngrc_fastslow_readout')       | 0.30146    |  4.58313   |  8.01427     | 0.631954   | 0.0634155   |
| ('highdim_chaotic', 'rc_fastslow_readout')        | 0.297365   |  5.02397   |  2.76736e+06 | 0.524077   | 0.0446063   |
| ('lowdim_chaotic', 'slow_sindy_only')             | 4.73066    |  5.73455   |  5.80348     | 0.167814   | 0.0327666   |
| ('lowdim_chaotic', 'slow_sindy_delta_hybrid')     | 2.74858    |  6.52742   | 10.9829      | 0.21261    | 0.029515    |
| ('lowdim_chaotic', 'slow_sindy_delta_ngrc')       | 3.69195    |  7.16417   |  7.53634     | 0.186788   | 0.0351382   |
| ('lowdim_chaotic', 'slow_sindy_delta_rc')         | 2.63038    | 12.2762    | 13.4588      | 0.288094   | 0.0529529   |

## Dimension scaling

|   state_dim | variant                 |    rmse@50 |     rmse@100 |   one_step_rmse |
|------------:|:------------------------|-----------:|-------------:|----------------:|
|           2 | rc_fastslow_readout     |  0.0201295 |  0.0251054   |     0.0289532   |
|           2 | slow_sindy_delta_hybrid |  0.231444  |  0.420101    |     0.0255222   |
|           2 | slow_sindy_delta_ngrc   |  0.328053  |  1.14988     |     0.0187894   |
|           2 | slow_sindy_delta_rc     |  0.334256  |  0.424531    |     0.0306344   |
|           2 | slow_sindy_only         |  0.339271  |  0.388249    |     0.186663    |
|           2 | hybrid_rc_ngrc_fastslow |  0.692434  |  0.754664    |     0.0214078   |
|           2 | ngrc_fastslow_readout   |  3.37981   |  5.21245     |     0.0391756   |
|           3 | hybrid_rc_ngrc_fastslow |  0.953255  |  4.79233     |     0.0125143   |
|           3 | rc_fastslow_readout     |  1.76611   |  2.31464     |     0.0302588   |
|           3 | ngrc_fastslow_readout   |  4.58313   |  8.01427     |     0.0180558   |
|           3 | slow_sindy_only         |  5.73455   |  5.80348     |     3.5167      |
|           3 | slow_sindy_delta_hybrid |  6.52742   | 10.9829      |     0.0793509   |
|           3 | slow_sindy_delta_ngrc   |  7.16417   |  7.53634     |     0.114837    |
|           3 | slow_sindy_delta_rc     | 12.2762    | 13.4588      |     0.0834276   |
|          16 | hybrid_rc_ngrc_fastslow |  1.13792   |  0.858179    |     0.000946721 |
|          16 | slow_sindy_only         |  1.59643   |  2.38328     |     1.94644     |
|          16 | rc_fastslow_readout     |  2.89264   |  5.05788     |     0.00669627  |
|          16 | slow_sindy_delta_rc     |  4.41886   |  3.56199     |     0.0759896   |
|          16 | ngrc_fastslow_readout   |  4.58045   | 13.7343      |     0.00410828  |
|          16 | slow_sindy_delta_hybrid |  6.44854   |  5.71754     |     0.0748252   |
|          16 | slow_sindy_delta_ngrc   |  6.72737   |  8.7971      |     0.07477     |
|          32 | ngrc_fastslow_readout   |  1.28364   |  3.13516     |     0.0184898   |
|          32 | slow_sindy_delta_rc     |  2.02397   |  6.64933     |     0.0661164   |
|          32 | slow_sindy_delta_ngrc   |  2.28793   |  4.41844     |     0.0482859   |
|          32 | slow_sindy_delta_hybrid |  2.4383    |  3.65844     |     0.0479077   |
|          32 | slow_sindy_only         |  2.56109   |  3.5259      |     1.81702     |
|          32 | hybrid_rc_ngrc_fastslow |  2.68984   |  6.29546     |     0.0182342   |
|          32 | rc_fastslow_readout     |  6.08963   |  4.15104e+06 |     0.0284419   |
|          80 | slow_sindy_delta_rc     |  0.413621  |  2.11099     |     0.0328969   |
|          80 | slow_sindy_delta_ngrc   |  0.513219  |  1.67543     |     0.0414965   |
|          80 | rc_fastslow_readout     |  0.524661  |  1.264       |     0.0288703   |
|          80 | ngrc_fastslow_readout   |  0.724479  |  1.66833     |     0.0281151   |
|          80 | slow_sindy_delta_hybrid |  0.728483  |  3.37504     |     0.0305442   |
|          80 | slow_sindy_only         |  1.03477   |  2.17174     |     1.40376     |
|          80 | hybrid_rc_ngrc_fastslow |  2.34561   |  3.23928     |     0.0286885   |
|          84 | rc_fastslow_readout     |  0.117645  |  0.147832    |     0.000128674 |
|          84 | hybrid_rc_ngrc_fastslow |  0.146139  |  1.07369     |     0.000112048 |
|          84 | ngrc_fastslow_readout   |  0.490639  |  2.24872     |     0.000227163 |
|          84 | slow_sindy_only         |  0.702443  |  1.9118      |     1.15028     |
|          84 | slow_sindy_delta_hybrid |  1.26325   |  4.01219     |     0.0206856   |
|          84 | slow_sindy_delta_rc     |  1.31046   |  5.9244      |     0.0206776   |
|          84 | slow_sindy_delta_ngrc   |  1.40773   |  3.74522     |     0.00827781  |

### Best variant per state dimension
|   state_dim | best_variant            |   task_count |   avg_rmse50 |   avg_rmse100 |
|------------:|:------------------------|-------------:|-------------:|--------------:|
|           2 | rc_fastslow_readout     |            4 |    0.0201295 |     0.0251054 |
|           3 | ngrc_fastslow_readout   |            3 |    4.58313   |     8.01427   |
|          16 | hybrid_rc_ngrc_fastslow |            1 |    1.13792   |     0.858179  |
|          32 | ngrc_fastslow_readout   |            2 |    1.28364   |     3.13516   |
|          80 | slow_sindy_delta_rc     |            1 |    0.413621  |     2.11099   |
|          84 | rc_fastslow_readout     |            1 |    0.117645  |     0.147832  |

## Ablation summary

| comparison                       | baseline                | candidate               |   tasks |   avg_rmse50_gain |   avg_rmse100_gain |   avg_mismatch_reduction | hypothesis                                                              |
|:---------------------------------|:------------------------|:------------------------|--------:|------------------:|-------------------:|-------------------------:|:------------------------------------------------------------------------|
| dual_memory_vs_single_memory     | rc_fastslow_readout     | hybrid_rc_ngrc_fastslow |      12 |          0.53785  |      691838        |               -445.414   | Combining recurrent and delay memories should improve horizon balance.  |
| hybrid_residual_vs_ngrc_residual | slow_sindy_delta_ngrc   | slow_sindy_delta_hybrid |      12 |          0.183667 |          -0.398972 |                  6.40692 | Adding reservoir memory should stabilize residual NGRC rollouts.        |
| slow_backbone_vs_none            | hybrid_rc_ngrc_fastslow | slow_sindy_delta_hybrid |      12 |         -1.59884  |          -1.65776  |                568.515   | A slow-manifold prior should help on multiscale high-dimensional tasks. |

## One-step vs long-horizon mismatch

| task                       | variant                 |   one_step_rmse |     rmse@50 |   mismatch_ratio |   state_dim |
|:---------------------------|:------------------------|----------------:|------------:|-----------------:|------------:|
| vanderpol_stiff            | ngrc_fastslow_readout   |     0.000304778 |  3.80461    |        12483.2   |           2 |
| lorenz96_k32_partial       | hybrid_rc_ngrc_fastslow |     0.000531059 |  1.81643    |         3420.4   |          32 |
| lorenz96_twoscale_k12_j6   | ngrc_fastslow_readout   |     0.000227163 |  0.490639   |         2159.85  |          84 |
| lorenz96_twoscale_k12_j6   | hybrid_rc_ngrc_fastslow |     0.000112048 |  0.146139   |         1304.25  |          84 |
| lorenz96_k16_partial       | hybrid_rc_ngrc_fastslow |     0.000946721 |  1.13792    |         1201.96  |          16 |
| lorenz96_k16_partial       | ngrc_fastslow_readout   |     0.00410828  |  4.58045    |         1114.93  |          16 |
| lorenz96_twoscale_k12_j6   | rc_fastslow_readout     |     0.000128674 |  0.117645   |          914.287 |          84 |
| lorenz63_clean             | ngrc_fastslow_readout   |     0.00399075  |  3.51003    |          879.541 |           3 |
| lorenz63_clean             | hybrid_rc_ngrc_fastslow |     0.00323371  |  2.71315    |          839.019 |           3 |
| lorenz96_k16_partial       | rc_fastslow_readout     |     0.00669627  |  2.89264    |          431.979 |          16 |
| rossler_clean              | hybrid_rc_ngrc_fastslow |     0.000121134 |  0.0484974  |          400.361 |           3 |
| lorenz96_k32_partial       | ngrc_fastslow_readout   |     0.00220129  |  0.854362   |          388.12  |          32 |
| lorenz96_k32_partial       | rc_fastslow_readout     |     0.0161968   |  4.80935    |          296.932 |          32 |
| lorenz63_noisy             | slow_sindy_delta_rc     |     0.0923605   | 22.8767     |          247.689 |           3 |
| lorenz63_noisy             | ngrc_fastslow_readout   |     0.0501243   | 10.2311     |          204.115 |           3 |
| lorenz96_k32_partial_noisy | rc_fastslow_readout     |     0.040687    |  7.3699     |          181.136 |          32 |
| lorenz96_twoscale_k12_j6   | slow_sindy_delta_ngrc   |     0.00827781  |  1.40773    |          170.061 |          84 |
| rossler_clean              | ngrc_fastslow_readout   |     5.22428e-05 |  0.00827122 |          158.323 |           3 |
| lorenz63_noisy             | slow_sindy_delta_ngrc   |     0.0796647   | 10.4109     |          130.683 |           3 |
| lorenz63_clean             | slow_sindy_delta_hybrid |     0.0667491   |  8.48747    |          127.155 |           3 |

## Insights

- The new slow-SINDy delta hybrid reduces residual-model mismatch relative to pure NGRC closure, suggesting that residual dynamics also benefit from recurrent state regularization.
- On the current high-dimensional tasks, `ngrc_fastslow_readout` wins most often, so claims should be framed around partial-observation structure rather than universal dominance.

## Theory-motivated next direction

- The most natural next direction is `slow_sindy_delta_hybrid`: a slow-manifold backbone plus a dual-memory residual closure.
- Theory link: under slow-fast decomposition and Mori-Zwanzig style reasoning, the resolved slow dynamics should be modeled explicitly, while unresolved memory effects are better captured by a closure term with both recurrent state and delay coordinates.
- Targeted experiment: compare `hybrid_rc_ngrc_fastslow`, `slow_sindy_delta_ngrc`, `slow_sindy_delta_rc`, and `slow_sindy_delta_hybrid` on the high-dimensional multiscale tasks only, then measure `rmse@50`, `rmse@100`, `acf_rmse`, and the one-step/rollout mismatch ratio.
- Current signal: `slow_sindy_delta_hybrid` is already implemented in this revision, so the new hypothesis is directly testable; its current average high-dimensional `rmse@50` is 2.663.
- Modular validation loop: keep the suite fixed, swap only one component family at a time, and use the ablation table to verify whether each theoretical ingredient improves the intended failure mode.

## Reviewer view

- Strength: the benchmark exposes that no single baseline dominates all regimes; `rc_fastslow_readout` is only the most frequent winner, not a universal winner.
- Strength: the updated suite now includes higher-dimensional Lorenz-96 scaling tasks, which makes the evaluation less vulnerable to the criticism that the benchmark is only low-dimensional.
- Weakness: all current comparisons stay within RC/NGRC/SINDy-style families; a reviewer would still want at least one modern sequence-model baseline or a clear justification for excluding it.
- Weakness: results appear to rely on a single random seed, so variance bars and multi-seed significance should be added before making strong superiority claims.
